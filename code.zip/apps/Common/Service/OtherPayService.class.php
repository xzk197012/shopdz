<?php
namespace Common\Service;
use Think\Model;

class OtherPayService {
	
	static $pay_state = array('wx'=>'微信','alipay'=>'支付宝','newalipay'=>'支付宝');
	/**
	 * 查询扫码支付数据
	 */
	static public function getOtherPaySn($order_sn){
        $model  = D('OtherPay');
		return $model->getOtherPaySn($order_sn);
	}
	/**
	 * 插入扫码支付数据
	 */
	static public function addOtherPayData($param){
		if($param['coupon_id']){
			$data = array(
	        	'order_sn'		=> $param['order_sn'],
	        	'payment_code'		=> self::$pay_state[$param['payment_code']],
	        	'order_amount'	=> $param['order_amount'],
	        	'before_amount'	=> $param['before_amount'],
	        	'offer_amount'	=> $param['offer_amount'],
	        	'coupon_id'	=> $param['coupon_id'],
	        	'pay_starttime' => TIMESTAMP
	        );
		}else{
			$data = array(
	        	'order_sn'		=> $param['order_sn'],
	        	'payment_code'		=> self::$pay_state[$param['payment_code']],
	        	'order_amount'	=> $param['order_amount'],
	        	'pay_starttime' => TIMESTAMP
	        );
		}
        
		$model = D('OtherPay');
		$res = $model->addOtherPayData($data);
		return $res;
	}
	/**
	 * 修改扫码支付数据
	 */
	static public function saveOtherPayData($data){
		$param = array(
        	'trade_no'=>$data['trade_no'],
        	'status'=>2, //修改为已支付
        );

		$model = D('OtherPay');
		//修改用户优惠卷状态;
		$coupon_id = $model->getCoupon($data['order_sn']);
		if($coupon_id){
			$where['id'] = array('in', $coupon_id);
			$coupon = array(
				'status'=>2,
			);
			$ret = M('user_coupon')->where($where)->save($coupon);
		}
		
		$res = $model->saveOtherPayData($param, $data['order_sn']);
		return $res;
	}
}