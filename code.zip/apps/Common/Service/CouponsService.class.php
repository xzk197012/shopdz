<?php
namespace Common\Service;
use Think\Model;
use Common\Wechat\WxcardController;
use Admin\Model\SettingModel;
class CouponService{
   //  获取可用优惠券模总数
  static function getCouponsCount()
  {

  }
 
}