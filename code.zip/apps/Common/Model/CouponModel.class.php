<?php

/**
 * 
 */
namespace Common\Model;
use Think\Model;
// use Think\Model\RelationModel;
class CouponModel extends Model
{
	public $errmsg = '';
	protected $tableName = 'user_coupon';

	//获取商家优惠卷数量	
	public function getCouponsCount()
	{
		$where['status'] = array('in','1');
		$count = M('coupons')->where($where)->select();
		if(!$count){
			$this->errmsg = '获取数据失败';
			return false;
		}
		return intval($count);
	}

	//获取商家优惠卷
	public function getCoupons($coupon_id=0, $start=0, $limit=0, $user_id=0)
	{	

		// $limitstr = '';
	 //    if($limit != 0){
	 //    	$limitstr = $start.','.$limit;
	 //    }
	    if(is_numeric($coupon_id) && count($coupon_id)!=0){
	    	$where['coupon_id'] = array('in',"$coupon_id");
	    }
	    $where['valid_end_time'] = array('gt',  time() );
	    $where['send_num'] = array('gt', 0);
	    $where['status'] = array('in', '1');
	    // $where['valid_start_time'] = array('LT',time());
	    $list = M('coupons')->where($where)->order('coupon_id DESC')->limit($limitstr)->select();
	    if(!$list){
	    	$this->errmsg = '获取数据失败';
	    	return false;
	    }
	   	$lists = array();
	    foreach ($list as $k => $v) {
	    	$where['id'] = array('in',$v['store_id']);
	    	if($user_id != 0){
	    		$coupon['user_id'] = array('in', "$user_id");	
	    	}
	    	$coupon['coupon_id'] = array('in', $v['coupon_id']);
	    	$count = M('user_coupon')->where($coupon)->count();
	    	if($count){
	    		continue;
	    	}
	    	// return $count;
			$store_name =  M('store')->field('store_name')->where($where)->select();
			if(!$store_name){
				$this->errmsg = '获取商家信息失败';
				return false;
			}
			$lists[$k]['store_name'] = $store_name[0]['store_name'];
			$lists[$k]['coupon_id'] = $list[$k]['coupon_id'];
			$lists[$k]['store_id'] = $list[$k]['store_id']; 
			$lists[$k]['coupon_name'] = $list[$k]['coupon_name'];
			$lists[$k]['coupon_type'] = $list[$k]['coupon_type'];
			$lists[$k]['coupon_money'] = $list[$k]['coupon_money'];
			$lists[$k]['discount'] = $list[$k]['discount'];
			$lists[$k]['spend_money'] = $list[$k]['spend_money'];
			$lists[$k]['coupon_des'] = $list[$k]['coupon_des'];
			$lists[$k]['send_num'] = $list[$k]['send_num'];
			$lists[$k]['receive_num'] = $list[$k]['receive_num'];
			$lists[$k]['valid_start_time'] = date('Y-m-d', $list[$k]['valid_start_time']);
			$lists[$k]['valid_end_time'] =  date('Y-m-d', $list[$k]['valid_end_time']);
			$lists[$k]['status'] = $list[$k]['status'];

	    }

	    return $lists;

	}

	//获取用户优惠卷数量
	public function getCouponCount($user_id, $coupon_id)
	{	
		if($user_id){
			$where['user_id'] = array('in', $user_id);
		}
		if($coupon_id){
			$where['coupon_id'] = array('in', $coupon_id);
		}
		try{
			$count = $this->where($where)->count();
		}catch(\Exception $e){
			$this->errmsg = '获取数据失败';
		}
		return $count;
	}

	//领取优惠卷
	public function addCoupon($user_id, $coupon_id)
	{	
		
		$where['coupon_id'] = array('in',$coupon_id);
		$count = M('coupons')->field('send_num')->where($where)->select();
		if($count < 1 || count($count)==0){
			$this->errmsg = '此优惠卷已发放完，再接再厉！';
			return false;
		}
		$data = array('user_id'=>$user_id,'coupon_id'=>$coupon_id);
		$ret = $this->add($data);
		if(!$ret){
			$this->errmsg = '添加数据失败';
			return false;
		}
		$ret = M('coupons')->where($where)->setDec('send_num');
		if(!$ret){
			$this->errmsg = '添加数据失败';
			return false;
		}
		$ret = M('coupons')->where($where)->setInc('receive_num');
		if(!$ret){
			$this->errmsg = '添加数据失败';
			return false;
		}
		return $count[0];
	}

	//用户优惠卷
	public function lists($user_id, $status, $store_id, $user_coupon_id)
	{
		//1:未使用 2：已使用 3：已过期
		if(!$user_coupon_id){
			if($status == 3){
				$whe['valid_end_time'] = array('lt',  time() );
				$where['status'] = array('in', "1");
			}else if($status == 1 || $status == 5){
				$whe['valid_end_time'] = array('gt', time() );
				$where['status'] = array('in', "1");
			}else{
				$where['status'] = array('in', $status);
			}
		}else{
			$where['id'] = array('in', $user_coupon_id);
		}	
		if($user_id){
			$where['user_id'] = array('in', $user_id);
		}
		$list = $this->where($where)->select();
		if(!$list){
			$this->errmsg = '获取用户优惠卷数据失败';
			return false;
		}

		if($store_id){
			$whe['store_id'] = array('in', $store_id);
		}
		$lists = array();
		foreach ($list as $k => $v) {
			$whe['status'] = array('in','1');
			$whe['coupon_id'] = array('in', $v['coupon_id']);
			$coupon = M('coupons')->where($whe)->select();
			if(!$coupon){
				continue;
			}
				$store['id'] = array('in', $coupon[0]['store_id']);
				$store_name =  M('store')->field('store_name')->where($store)->select();
				if(!$store_name){
					$this->errmsg = '获取商家信息失败';
					return false;
				}
				$coupon['id'] = $v['id'];
				$coupon['coupon_id'] = $coupon[0]['coupon_id'];
				$coupon['store_id'] = $coupon[0]['store_id']; 
				$coupon['coupon_name'] = $coupon[0]['coupon_name'];
				$coupon['coupon_type'] = $coupon[0]['coupon_type'];
				$coupon['coupon_money'] = $coupon[0]['coupon_money'];
				$coupon['discount'] = $coupon[0]['discount'];
				$coupon['spend_money'] = $coupon[0]['spend_money'];
				$coupon['coupon_des'] = $coupon[0]['coupon_des'];
				$coupon['send_num'] = $coupon[0]['send_num'];
				$coupon['receive_num'] = $coupon[0]['receive_num'];
				$coupon['valid_start_time'] = date('Y-m-d', $coupon[0]['valid_start_time']);
				$coupon['valid_end_time'] =  date('Y-m-d', $coupon[0]['valid_end_time']);
				$coupon['status'] = $coupon[0]['status'];
				$coupon['store_name'] = $store_name[0]['store_name'];
				if($status == 3){
					$coupon['user_status'] = 3;
				}else{
					$coupon['user_status'] = $v['status'];	
				}
				$lists[] = $coupon;
		}
		return $lists;

	}
}