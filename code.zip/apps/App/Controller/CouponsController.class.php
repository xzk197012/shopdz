<?php
namespace App\Controller;
use Think\Controller;
use Common\Model\CouponModel;
use Common\Wechat\WxCardController;

class CouponsController extends BaseController {

	public function __construct() {
		$this->getMember();
	}


	public function lists(){
		// 1：未使用  2：已使用  3：已失效  4：全部
		$model = new \Common\Model\CouponModel();
		$status = I('request.status') ? intval(I('request.status')) : 4;
		$page = intval(I('post.page')) ? intval(I('post.page')) : 1;
		$limit = 10;
		$start = ($page-1)*$limit;
		$user_id = $this->member_info['member_id'];
		$points = $this->member_info['member_points'];
		if($status == 4){
			$num = $model->getCouponsCount();
			$havepage = ceil($num/$limit);
			$list = $model->getCoupons(null, $start, $limit, $user_id);
		}
		$data['list'] = $list;
		$data['status'] = $status;
		$data['havepage'] = $havepage;
		$data['page'] = $page;
		$data['points'] = $points;
		$this->returnJson(0,'sucess',$data);
	}

	public function user_lists()
	{	

		$status = I('request.status');
		$store_id = I('get.store_id');
		$user_coupon_id = I('get.id');
		$model = D('Coupon');
		$user_id = $this->member_info['member_id'];
		$list = $model->lists($user_id, $status, $store_id,$user_coupon_id);
		$data['list'] = $list;
		$time = time();
		// $this->returnJson(0, 'sucess', $model->errmsg);
		$this->returnJson(0, 'sucess', $data);
	}

	
	public function coupon_insert()
	{	

		$coupon_id = I('get.coupon_id');
		$user_id = $this->member_info['member_id'];
		if(!$coupon_id){
			$this->returnJson(1,'参数错误，请重试！');
		}
		if(!$user_id){
			$this->returnJson(1,'你还未登录，请登录！');
		}

		$CouponModel = new \Common\Model\CouponModel();
		$count = $CouponModel->getCouponCount($user_id, $coupon_id);
		if($count){
			$this->returnJson(1,'领取已达上限，不能再领了');
		}
		
		$CouponModel = new \Common\Model\CouponModel();
		$temp =  $CouponModel->getCoupons(intval($coupon_id), $user_id);
		if(!$temp || $temp[0]['send_num'] < 1){
			$this->returnJson(1,'此优惠卷已发放完！');
		}
		if(time() > strtotime($temp[0]['valid_end_time'])){
			$this->returnJson(1,'优惠券已过期！');
		}
		
		$ret = $CouponModel->addCoupon($user_id, $coupon_id);
		if(!$ret){
			$this->returnJson(1,'优惠卷发放失败，请重试！');
		}
		$this->returnJson(0,'sucess',$CouponModel->errmsg);
	}

}