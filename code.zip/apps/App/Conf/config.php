<?php
return array(
	//'配置项'=>'配置值'
	//'COOKIE_DOMAIN' => '.comsenz-service.com',
	'COOKIE_PREFIX' => 'pre_', //cookie的前缀
	'VAR_FILTERS'=>'htmlspecialchars,trim',
);