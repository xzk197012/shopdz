<?php
/**
 * 
 */
namespace Admin\Controller;
use Think\Controller;
class StoreController extends BaseController
{	

	public function browse()
	{	
		$model = new \Admin\Model\StoreModel();
		$data = $model->index( trim(I('post.store_name')), I('post.status') );
		$count = $model->count();
		// var_dump($count);
		$this->assign('count', $count);
		$this->assign('ret',$data[0]);
		$this->assign('page',$data[1]);
		$this->display();
	}	
	
	public function add()
	{
		$this->display();
	}
	public function save()
	{
		if(I('post.submit') != 'yes'){
			$this->error('请通过正确的渠道提交');
			return false;
		}

		$id = I('post.storeId');
		$post = array(
				'store_name'=>trim(I('post.store_name')), 
				'address'=>trim(I('post.address')), 
				'store_tel'=>trim(I('post.store_tel')), 
				'status'=>trim(I('post.status')), 
				'details'=>trim(I('post.details')),
			);
		if(!$post['store_name']){
			$this->error("商家名称不能为空");
		}
		if(!$post['address']){
			$this->error('商家地址不能为空');
		}
		if(!$post['store_tel']){
			$this->error('商家电话不能为空');
		}
		if(!$post['status']){
			$this->error('商家状态不能为空');
		}

		$model = new \Admin\Model\StoreModel();
		if($data = $model->insert($post,$id)){
			$this->success("$data[1]");
		}else{
			$this->error("$model->errmsg");
		}
	}

	public function edit()
	{
		$storeId = trim(I('get.store_id'));
		if(!$storeId){
			return $this->error('缺少必要的参数');
		}
		$model = new \Admin\Model\StoreModel();
		$dat = $model->edit(I('get.store_id'));
		$this->assign('data',$dat);
		$this->display();
	}

	public function del()
	{
		$id = I('get.store_id');
		$submit = I('get.submit');
		if(!$submit){
			$this->ajaxReturn(array('info'=>'请通过正确的渠道提交'));
			return false;
		}
		// $this->ajaxReturn(array('status'=>1, 'info'=>$id));
		$model = new \Admin\Model\StoreModel();
		if($data = $model->del($id)){
			$this->ajaxReturn(array('status'=>1, 'info'=>'删除数据成功'));
		}else{
			$this->ajaxReturn(array('info'=>"$model->errmsg"));
		}
	}

	//商家二维码
	public function code()
	{
		$store_id = I('get.store_id');
		$store_name = I('get.store_name');
		$model = D('Setting');
		//获取配置
        $logo = $model -> getSetting('shop_logo');
		$this->assign('qrcode_url',SITE_URL .'wap/yimapay.html?store_id='.$store_id);
		$this->assign('logo_url',SITE_URL .'data/Attach/'.$logo);
		$this->assign('store_id', $store_id);
		$this->display('store-code');
		var_dump($store_id,$store_name);die;
	}
	
}
