<?php
namespace Admin\Controller;
use Think\Controller;
class TemplateController extends BaseController {
	public function freightTemplate2(){
		$this->display('freightTemplate2');
    }
	public function freightTemplate(){
		$this->display('freightTemplate');
    }
	public function data(){
		$this->display('data');
    }
	public function fightGroupChoice(){
		$this->display('fightGroupChoice');
    }
	public function FightGroups(){
		$this->display('FightGroups');
    }
	public function iconAlert(){
		$this->display('iconAlert');
    }
	public function coupon(){
		$this->display('coupon');
    }
	public function management(){
		$this->display('management');
    }
	public function tonglan(){
		$this->display('tonglan');
    }
	public function logistics(){
		$this->display('logistics');
    }
	public function LogisticsDetails(){
		$this->display('LogisticsDetails');
    }
	public function select(){
		$this->display('select');
    }
	public function firstpage(){
		$this->display('firstpage');
    }
	public function addSpec(){
		$this->display('addSpec');
    }
	public function addFocus(){
		$this->display('addFocus');
    }
	public function deleCoupon(){
		$this->display('deleCoupon');
    }
	public function login(){
		$this->display('login');
    }
	public function notice(){
		$this->display('notice');
    }
	public function deliverSetting(){
		$this->display('deliverSetting');
    }
	public function shippedSetting(){
		$this->display('shippedSetting');
    }
	public function orderDisplay(){
		$this->display('orderDisplay');
    }
	public function commodityControl(){
		$this->display('commodityControl');
    }
	public function releaseFive(){
		$this->display('releaseFive');
    }
	public function releaseFour(){
		$this->display('releaseFour');
    }
	public function releaseThree(){
		$this->display('releaseThree');
    }
	public function releaseTwo(){
		$this->display('releaseTwo');
    }
	public function releaseOne(){
		$this->display('releaseOne');
    }
	public function statistics(){
		$this->display('statistics');
    }
	public function survey(){
		$this->display('survey');
    }
	public function nav(){
		$this->display('nav');
    }
	public function details2(){
		$this->display('details2');
    }
	public function details(){
		$this->display('details');
    }
	public function classify(){
		$this->display('classify');
    }
	public function evaluate(){
		$this->display('evaluate');
    }
	public function address(){
		$this->display('address');
    }
	public function ImgUpload2(){
		$this->display('ImgUpload2');
    }
	public function Index(){
		$this->display('Index');
    }
	public function OrderProductList(){
		$this->display('OrderProductList');
    }
	public function Tit(){
		$this->display('Tit');
    }
	public function show_index(){
		$this->display('show_index');
    }
	public function Popup(){
		$this->display('Popup');
    }
	public function Color(){
		$this->display('Color');
    }
	public function OrderDetails(){
		$this->display('OrderDetails');
    }
	public function ImgUpload(){
		$this->display('ImgUpload');
    }
	public function SKU(){
		$this->display('SKU');
    }
	public function MailSetting(){
		$this->display('MailSetting');
    }
	public function AddArea(){
		$this->display('AddArea');
    }
	public function RegionalSetting(){
		$this->display('RegionalSetting');
    }
	public function BasicSetting(){
		$this->display('BasicSetting');
    }
	public function OrderMaganement(){
		$this->display('OrderMaganement');
    }
	public function addgroup(){
		$this->display('addgroup');
    }
	public function memberList(){
		$this->display('memberlist');
    }
    public function premissions(){
        $this->display('premissions');
		//$this->display('customer');
    }
	 
	
}