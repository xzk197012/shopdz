<?php

/**
 * 
 */
namespace Admin\Controller;
use Think\Controller;
class CouponsController extends BaseController
{
	public function lists()
	{	
		$ctype = I('get.coupon_type');

		$store_name = trim(I('post.store_name'));
		$coupon_name = trim(I('post.coupon_name'));
		$model = new \Admin\Model\CouponModel();
		if( !$data = $model->lists($coupon_name, $store_name, trim($ctype)) ){
			$this->error("$model->errmsg");
		}
		if($data['count'] == 1){
			$this->assign('type',$ctype);
			$this->assign('count',$data['count']);
			$this->display();
		}
		$this->assign('type',$ctype);
		$this->assign('sousuo', array('store_name'=>$store_name, 'coupon_name'=>$coupon_name));
		$this->assign('coupons',$data[0]);
		$this->assign('page',$data[1]);
		$this->display();
	}

	public function add()
	{	
		// var_dump(I('get.'));die;
		$store = I('get.');
		$this->assign('ret',$store);
		$this->display();
	}

	public function save()
	{	
		// var_dump(I('post.valid_start_time'));die;
		$submit = I('post.submit');
		if($submit != 'yes'){
			$this->error('请通过正确的渠道提交');
		}

		$coupon_id = I('post.coupon_id');
		$store_id = trim(I('post.store_id'));
		$coupon_name = trim( I('post.coupon_name') );
		$coupon_type = trim( I('post.coupon_type') );
		$coupon_money = trim( I('post.coupon_money') );
		$spend_money = trim(I('post.spend_money') ) ;
		$send_num = trim( I('post.send_num') );
		$valid_start_time = trim( I('post.valid_start_time') );
		$valid_end_time = trim( I('post.valid_end_time') );
		$status = trim( I('post.status') );
		$limited = trim( I('post.limited') );
		$discount = trim( I('post.discount') );
		if(!$store_id){
			return $this->error('缺少商家ID参数');
		}

		if(!$coupon_type){
			return $this->error('请选择优惠卷类型');
		}

		if(!$coupon_name){
			return $this->error('优惠卷名称不能为空');
		}else if(mb_strlen($couponName) > 50){
			return $this->error('优惠卷名称超过50字符');
		}
		
		if(!$send_num){
			return $this->error('优惠卷总量不能为空');
		}

		if(!$coupon_money && !$discount){
			return $this->error('优惠卷（面值或折扣）不能为空');
		}

		if(!$spend_money){
			return $this->error('订单金额不能为空');
		}
		if($spend_money <= $couponMoney){
			return $this->error('订单金额必须大于优惠卷面额');
		}
		if(!$valid_start_time){
		return $this->error('生效时间不能为空');
		}else if(strtotime($valid_start_time) < time() && !($coupon_id)){
			return $this->error('生效时间不能小于当前时间');
		}else if(strtotime($valid_start_time) >= strtotime($valid_end_time)){
			return $this->error('过期时间不能小于生效时间');
		}
		if(!$valid_end_time){
			return $this->error('过期时间不能为空');
		}
		if(!$status){
			return $this->error('优惠卷状态缺少有效参数');
		}
		if($discount){
			$reg = "/^((0\.[1-9]{1})|(([1-9]{1})(\.\d{1})?))$/" ;
			$data = preg_match($reg, $discount);
			if(!$data){
				$this->error('折扣格式不正确');
			}
		}
		$coupon = array(
			'store_id'=>$store_id,
			'coupon_name'=>$coupon_name,
			'coupon_type'=>$coupon_type,
			'coupon_money'=>$coupon_money,
			'spend_money'=>$spend_money,
			'send_num'=>$send_num,
			'valid_start_time'=> strtotime($valid_start_time),
			'valid_end_time'=> strtotime($valid_end_time),
			'status'=>$status,
			'limited'=>$status,
			'discount'=>$discount,
			'create_time'=>time(),
		);
		$model = new \Admin\Model\CouponModel();
		if($data = $model->insert($coupon, $coupon_id)){
			$this->success("$data[1]");
		}else{
			$this->error("$model->errmsg");
		}
	}

	public function edit()
	{	

		$id = I('get.coupon_id');
		$submit = I('get.submit');
		// var_dump($id);die;
		if($submit != 'yes'){
			$this->error('请通过正确的渠道提交');
			return false;
		}
		$model = new \Admin\Model\CouponModel();
		if( $data = $model->lists($coupon_name=null, $store_name=null, $ctype=null, $coupon_id=$id) ){
			$this->assign('coupon',$data[0]);
			$this->display();
		}else{
			$this->error("$model->errmsg");
		}

	}


	public function delete()
	{
		if(!I('get.submit')){
			$this->ajaxReturn(array('info'=>'请通过正确的渠道提交'));
			return false;
		}
		$coupon_id = I('get.coupon_id');

		if(!$coupon_id){
			$this->ajaxReturn(array('info'=>'缺少必要的参数'));
			return false;
		}
		// $this->ajaxReturn(array('status'=>1, 'info'=>$coupon_id));

		$model = new \Admin\Model\CouponModel();
		if($data = $model->del($coupon_id)){
			$this->ajaxReturn(array('status'=>1, 'info'=>'删除成功'));
		}else{
			$this->ajaxReturn(array('info'=>"$model->errmsg"));
		}

	}

	
}