<?php

/**
 * 
 */
namespace Admin\Model;
use Think\Model;
// use Think\Model\RelationModel;
class CouponModel extends Model
{
	
	public $errmsg = '';
	protected $tableName = 'coupons';

	public function lists($coupon_name=null, $store_name=null, $ctype=null, $coupon_id=0)
	{	
		$storeModel = new StoreModel();
		if( trim($coupon_name) ){
			$where['coupon_name'] = array('like', '%'.$coupon_name.'%');
		}

		if($ctype == '1'){
			$where['coupon_type'] = array('in','1');
		}
		if($ctype == '2'){
			$where['coupon_type'] = array('in','2');
		}
		if($coupon_id!=0){
			$where['coupon_id'] = array('in',$coupon_id);
		}

		$lists = array();
		if($store_name != null){
			$store['store_name'] = array('like', '%'.$store_name.'%');
			$store_id = D('Store')->field('id')->where($store)->select();
			foreach ($store_id as $k => $v) {
				$where['store_id'] = array('in', $v['id']);
				// $lists[] = $this->where($where)->select();
				$lists[] = $this->where($where)->limit($page->firstRow.','.$page->listRows)->order('coupon_id DESC')->select();
			}
			$list = array();
			$count = 0;
			foreach ($lists as $key => $value) {
				$count += count($value);
				foreach ($value as $kk => $vv) {
					$list[] = $vv;
				}
			}
			$page  = new \Common\Helper\PageHelper($count,10);
	        $pag = $page->show();
			// return array($data, $pag);
		}else{
			$count = $this->where($where)->count();
	        $page  = new \Common\Helper\PageHelper($count,10);
	        $pag = $page->show();
	        $list = $this->where($where)->limit($page->firstRow.','.$page->listRows)->order('coupon_id DESC')->select();
		}
        $data = array();
        if($count!=0){
	        if($list){
		        foreach ($list as $val) {
		        	$where['id'] = array('in',$val['store_id']);
					$storeName = $storeModel->field('store_name')->where($where)->select();
					if(!$storeName){
						$this->errmsg = '获取商家信息失败';
						return false;
					}
		            $i['store_name'] =  $storeName[0]['store_name'];
		            $i['store_id'] =  $val['store_id'];
		        	$i['coupon_id'] = $val['coupon_id'];
		            $i['coupon_name'] = $val['coupon_name'];
		            $i['coupon_type'] = $val['coupon_type'];
		            $i['coupon_money'] = $val['coupon_money'];
		            $i['spend_money'] = $val['spend_money'];
		            $i['send_num'] = $val['send_num'];
		            $i['valid_start_time'] = date('Y-m-d ',$val['valid_start_time']);
		            $i['valid_end_time'] =  date('Y-m-d ',$val['valid_end_time']);
		            $i['status'] = $val['status'];
		            $i['limited'] = $val['limited'];
		            $i['create_time'] =  date('Y-m-d H:i:s', $val['create_time']);
		            $i['receive_num'] = $val['receive_num'];
		            $i['discount'] = $val['discount'];
		            $data[$val['coupon_id']] = $i;
		        }
		        return array($data, $pag);
	        }else{
	        	$this->errmsg = '获取优惠卷信息失败';
	        	return false;
	        }
        }
        return $data = array('count'=>1);
	
	}

	public function insert($coupon,$coupon_id)
	{	

		if(!$coupon_id){
			// $where['coupon_name'] = array('in',$coupon['coupon_name']);
			// $couponName = $this->where($where)->select();
			// if($couponName){
			// 	$this->errmsg = '此优惠卷名称已经存在';
			// 	return false;
			// }
			$ret = $this->add($coupon);
			if(!$ret || count($ret) != 1){
				return $this->errmsg = '添加数据失败';
			}
			return array($ret,'添加优惠卷成功');
		}else{
			$where['coupon_id'] = array('in',$coupon_id);
			$ret = $this->where($where)->save($coupon);
			if(!$ret || count($ret)!=1){
				$this->errmsg = '修改数据失败';
			}
			return array($ret,'修改数据成功');
		}
		
	}

	public function del($coupon_id)
	{
		$where['coupon_id'] = array('in', $coupon_id);

		$count = M('user_coupon')->where($where)->select();
		if($count){
			$user_coupon = M('user_coupon')->where($where)->delete();
			if(!$user_coupon || count($user_coupon)!=1){
				$this->errmsg = '删除用户优惠卷失败';
				return false;
			}
		}
		$ret = $this->where($where)->delete();

		 if(!$ret || count($ret)!=1){
		 	$this->errmsg = '删除优惠卷失败';
		 	return false;
		 }

		 return $ret;

	}
}