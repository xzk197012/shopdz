<?php

/**
 * 
 */
namespace Admin\Model;
use Think\Model;
class StoreModel extends Model
{	
	public $errno = 0;
	public $errmsg = "";
	protected $tableName = "store";
    protected $_validate = array();

    public function index($store_name, $status)
    {	
    	if(trim($store_name)){
    		$where['store_name'] = array('like','%'.$store_name.'%');
    		$val['store_name'] = $store_name;
    	}
    	if($status && $status!=0){
    		$where['status'] = array('in',$status);
    		$val['status'] = $status;
    	}
        $count = $this->where($where)->count();
        $page  = new \Common\Helper\PageHelper($count,10);
        $pag = $page->show();
        $list = $this->where($where)->limit($page->firstRow.','.$page->listRows)->order('id DESC')->select();
        $data = array();
        foreach ($list as $val) {
        	$i['id'] = $val['id'];
            $i['store_name'] = $val['store_name'];
            $i['address'] = $val['address'];
            $i['yy_time'] = $val['yy_time'];
            $i['details'] = $val['details'];
            $i['store_tel'] = $val['store_tel'];
            $i['status'] = $val['status'];
            $data[$val['id']] = $i;
        }
    	
    	return array($data, $pag);
    }

    //添加商家和修改商家信息
	public function insert($data, $id = 0)
	{	
		if($id != 0 ){
			//修改商家
			$where['id'] = array('exp',"in($id)");
			$storeId = $this->where($where)->save($data);
			if(!$storeId){
				$this->errmsg = '修改数据失败';
			}
			return array($storeId, '修改数据成功');
		}else{
			$where['store_name'] = array("in",$data['store_name']);
			$store_name = $this->where($where)->select();
			if(!$store_name){
				$res = $this->add($data);
				if($res){
					return array($res, '添加商家成功');
				}else{
					$this->errmsg = '添加数据失败';
					return false;
				}
			}else{
				$this->errmsg = '该商铺已存在';
				return false;
			}	
		}
		
	}

	
	public function edit($id)
	{
		$where['id'] = array('exp',"in($id)");
		try{
			$store = $this->where($where)->select();
		}catch(\Exception $e){
			$this->errmsg = '获取数据失败';
			return false;
		}
		return $store;
	}

	//删除商家
	public function del($id)
	{
		$where['store_id'] = array('in', $id);
		$model = new CouponModel();
		$ret = $model->where($where)->select();
		if($ret){
			$this->errmsg = '商家属下有优惠卷，不能删除';
			return false;
		}
		$where['id'] = array('in', $id);
		$ret = $this->where($where)->delete();
		if(!$ret){
			$this->errmsg = '删除数据失败';
			return false;
		}

		return $ret;
		
	}

	//添加优惠卷商家模糊查询
	public function search($store_name)
	{	
		if($store_name){
			$where['store_name'] = array('like','%'.$store_name.'%');
			try{
				$name = $this->field('store_name')->where($where)->select();
			}catch(\Exception $e){
				$this->errmsg = '获取数据失败';
				return false;
			}
			return $name;
		}
	}
			
}