<?php
/**
 * this file is not freeware
 * User: al_bat
 * DATE: 2016/4/15
 */
namespace Admin\Model;
use Think\Model;
class RoleModel extends Model{
}