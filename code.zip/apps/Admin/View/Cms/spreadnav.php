﻿			<ul class="transverse-nav">
				<li <?php if(ACTION_NAME =='reward'){?> class="activeFour" <?php }?> ><a href="<?=U('Cms/reward'); ?>"><span>奖励设置</span></a></li>
				<li <?php if(ACTION_NAME =='presales'){?> class="activeFour" <?php }?> ><a href="<?=U('Cms/presales'); ?>"><span>奖励明细</span></a></li>
			</ul>