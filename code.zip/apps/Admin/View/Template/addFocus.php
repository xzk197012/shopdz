		<div class="cover"></div>
		<div class="alert showAlert radius3 addFocus-alert specialAlert">
			<i class="close-icon"></i>
			<h1 class="special-tit">添加幻灯图片</h1>
			<div class="special-con addSpec-con">
				<span class="special-con-left left">图片</span>
				<div class="input-group">
                    <span class="previewbtn"><img src="images/imgGray.png" class="viewimgbtn3 viewimg"/></span>
                    <input type="text" name="shop_logo" value="" class="form-control upload-inp com-inp1 radius3 boxsizing">
                    <input type="file"   id="shop_logo" class="form-control" style="display: none;">
                    <span class="input-group-btn left">
                        <!--<button class="btn2 test-btn com-btn1 upload-btn2" id="up" type="button" onclick="">选择文件</button>-->
                        <input type="button"  value="选择文件" class="upload-btn search-btn"/>
                    </span>
                </div>
				<div class="clear"></div>
				<div class="alerrt-sele-box">
					<span class="special-con-left left">操作</span>
					<select name="" id="" class="left addFocus-sele">
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
					</select>
					<!--<select name="" id="" class="left addFocus-sele">
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
						<option value="">操作操作操作</option>
					</select>-->
					<input type="text" class="com-inp1 radius3 boxsizing left addFocus-inp">
					<div class="clear"></div>
				</div>
			</div>
			<div class="alert-btnbox boxsizing">
				<a class="btn1 radius3">确认</a>
			</div>
		</div>