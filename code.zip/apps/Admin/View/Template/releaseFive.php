
		<ul class="release-tab">
			<li class="radius5">1.&nbsp;基本信息</li>
			<li class="radius5">2.&nbsp;规格设置</li>
			<li class="radius5">3.&nbsp;运费设置</li>
			<li class="radius5">4.&nbsp;参数设置</li>
			<li class="activeRelease radius5">5.&nbsp;发布成功</li>
		</ul>
		<!--内容开始-->
		<div class="iframeCon">
			<div class="white-bg">
				<h1 class="release-tit boxsizing">步骤五：发布成功</h1>
				<div class="release-success">
					<div class="success-left left">
						<h1 class="re-success-tit"><i class="success-icon"></i><span class="success-tit-word">发布成功!</span></h1>
						<p class="success-href-box">
							<a href="#" class="success-href">去店铺查看详情></a>
							<a href="#" class="success-href">重新编辑刚发布的商品></a>
						</p>
						<div class="success-btn-box">
							<input type="button" name="" id="" class="success-btn radius3 marR20 btn1" value="继续发布新商品"/>
							<input type="button" name="" id="" class="success-btn radius3 btn1" value="查看上架商品"/>
						</div>
					</div>
					<div class="success-right right">
						<div class="commidity-code-box">
							<img src="../images/qrcode.png" alt=""  class="commidity-code"/>
							<p class="commidity-word">扫码查看商品详情</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--内容结束-->
		

