		<style type="text/css">
			.picbg {
				display: block;
				margin: 50px auto 0 auto;
			}
		</style>
        <div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
        <!--内容开始-->
        <div class="iframeCon">
		<div class="iframeMain">
            <ul class="transverse-nav">
                <li class="activeFour"><a href="javascript:;"><span>预置通栏模板</span></a></li>
            </ul>
            <div class="white-bg ">
                <div class="jurisdiction boxsizing">
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商城名称：</dt>
                        <dd class="left text-l">
                            <select name="" id=""class="w140">
                            	<option value="">文字标题一</option>
                            	<option value="">文字标题一</option>
                            	<option value="">文字标题一</option>
                            	<option value="">文字标题一</option>
                            	<option value="">文字标题一</option>
                            	<option value="">文字标题一</option>
                            </select>
                            <p class="remind1">这里是提示信息</p>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing paddingT10">关闭原因：</dt>
                        <dd class="left text-l paddingT10">
                        	<div class="left">
                        		<textarea type="text" name="close_reason" class="com-textarea1 radius3 boxsizing banner-text"></textarea>
                           		<p class="remind1">这里是提示文字</p>
                        	</div>
                        	<div class="left preview-jt">
                        		<i class="preview-jtR"></i>
                        	</div>
                            <div class="preview-box left">
                            	<div class="preview-img-box">
                            		<img src="__PUBLIC__/admin/images/picbg.png" class="picbg"/>
                            	</div>
                            	<p class="preview-word">通栏样式预览</p>
                            </div>
                            <div class="clear"></div>
                            <div class="copy-box">
                            	<i class="copy-icon"></i>
                            	<p class="copy-remind">点击复制至下方</p>
                            </div>
                            <textarea type="text" name="close_reason" class="com-textarea1 radius3 boxsizing banner-text"></textarea>
                            <p class="remind1">这里是提示文字</p>
                        </dd>
                    </dl>
                </div>
                <div class="btnbox3 boxsizing">
                    <a type="button" id="base_setting" class="btn1 radius3 marginT10 btn3-btnmargin">确认提交</a>
                    <a type="button" id="base_setting" class="btn1 radius3 marginT10">返回上页</a>
                </div>
            </div>
        </div>  
        </div>  
        <!--内容结束-->

