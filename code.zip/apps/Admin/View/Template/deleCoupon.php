
		<div class="cover"></div>
		<div class="alert showAlert radius3 deleCoupon-alert specialAlert">
			<i class="close-icon"></i>
			<h1 class="special-tit">删除用户优惠券</h1>
			<div class="special-con">
				<span class="special-con-left left">是否返还积分</span>
				<div class="button-holder left">
					<p class="radiobox"><input type="radio" id="radio-1-1" name="radio-1-set" class="regular-radio" checked="checked"/><label for="radio-1-1"></label><span class="radio-word">是</span></p>
					<p class="radiobox"><input type="radio" id="radio-1-2" name="radio-1-set" class="regular-radio"/><label for="radio-1-2"></label><span class="radio-word">否</span></p>
				</div>
				<div class="clear"></div>
			</div>
			<div class="alert-btnbox boxsizing">
				<a class="btn1 radius3">确认</a>
			</div>
		</div>