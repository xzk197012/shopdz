		<div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
		<!--内容开始-->
		<div class="iframeCon">
			<div class="white-bg">
				<div class="jurisdiction boxsizing">
					<dl class="juris-dl boxsizing">
						<dt class="left text-r boxsizing"><span class="redstar">*</span>商品名称：</dt>
						<dd class="left text-l">
							<input type="text" class="com-inp1 radius3 boxsizing"/>
							<p class="remind1">这是提示文字</p>
						</dd>
					</dl>
					<dl class="juris-dl boxsizing data-dl">
						<dt class="left text-r boxsizing"><span class="redstar">*</span>数据调用商品：</dt>
						<dd class="left text-l">
							<!--<input type="button" value="添加商品" class="group-choice-btn"/>-->
         					<div class="data-operBox">
         						<div class="group-choice-again">
         							<p class="fight-pro-name data-pro-name"><a href="#">商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称</a></p>
         							<span class="data-operation">操作<i class="data-icon"></i></span>
         						</div>
         						<ul class="simulate-sele">
         							<li><a href="#">修改</a></li>
         							<li><a href="#">删除</a></li>
         						</ul>
         					</div>
							<p class="remind1">以SPU为单位，选择商品</p>
						</dd>
					</dl>
					<dl class="juris-dl boxsizing data-dl">
						<dt class="left text-r boxsizing"><span class="redstar">*</span>数据调用商品：</dt>
						<dd class="left text-l">
							<input type="button" value="添加商品" class="group-choice-btn"/>
         					<!--<div class="data-operBox">
         						<div class="group-choice-again">
         							<p class="fight-pro-name data-pro-name"><a href="#">商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称</a></p>
         							<span class="data-operation">操作<i class="data-icon"></i></span>
         						</div>
         						<ul class="simulate-sele">
         							<li><a href="#">修改</a></li>
         							<li><a href="#">删除</a></li>
         						</ul>
         					</div>-->
							<p class="remind1">以SPU为单位，选择商品</p>
						</dd>
					</dl>
					<dl class="juris-dl boxsizing data-dl">
						<dt class="left text-r boxsizing"><span class="redstar">*</span>数据调用商品：</dt>
						<dd class="left text-l">
							<table class="data-table">
								<thead>
									<tr>
										<th width="40">排序</th>
										<th colspan="2">
											商品信息
										</th>
										<th width="60">SPU</th>
										<th width="80">价格</th>
										<th width="60">库存</th>
										<th colspan="2">显示图片</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<span class="data-sort">1</span>
										</td>
										<td width="50" class="text-c">
											<a href="#">
												<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
											</a>
										</td>
										<td width="218" class="text-l">
											<div class="data-goods-det">
												几个客户的法国海军返回多客户几个客户的回多个地方
											</div>
										</td>
										<td>111</td>
										<td>6666.00</td>
										<td>100000</td>
										<td width="262">
											<div class="input-group data-group">
		                                        <span class="previewbtn"><img src="__PUBLIC__/admin/images/imgGray.png" class="viewimg data-viewIcon" id="logo_img"/></span>
		                                        <input type="text" name="shop_logo"  class="form-control data-inp com-inp1 radius3 boxsizing" localrequired="">
		                                        <input type="file"  class="form-control" style="display: none;">
		                                        <span class="input-group-btn left">
		                                            <input type="button"  value="选择文件" class="upload-btn search-btn data-upBtn"/>
		                                        </span>
		                                    </div>
										</td>
										<td><i class="data-dele-icon"></i></td>
									</tr>
									<tr>
										<td>
											<span class="data-sort">2</span>
										</td>
										<td width="50" class="text-c">
											<a href="#">
												<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
											</a>
										</td>
										<td width="218" class="text-l">
											<div class="data-goods-det">
												几个客户的法国海军返回多客户几户户的法国海军返回多个地方
											</div>
										</td>
										<td>111</td>
										<td>6666.00</td>
										<td>100000</td>
										<td>
											<div class="input-group data-group">
		                                        <span class="previewbtn"><img src="__PUBLIC__/admin/images/imgGray.png" class="viewimg data-viewIcon" id="logo_img"/></span>
		                                        <input type="text" name="shop_logo"  class="form-control data-inp com-inp1 radius3 boxsizing" localrequired="">
		                                        <input type="file"  class="form-control" style="display: none;">
		                                        <span class="input-group-btn left">
		                                            <input type="button"  value="选择文件" class="upload-btn search-btn data-upBtn"/>
		                                        </span>
		                                    </div>
										</td>
										<td><i class="data-dele-icon"></i></td>
									</tr>
									<tr>
										<td>
											<span class="data-sort">3</span>
										</td>
										<td width="50" class="text-c">
											<a href="#">
												<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
											</a>
										</td>
										<td width="218" class="text-l">
											<div class="data-goods-det">
												几个客户的法国海军返回多客户几个客户的法回多客户的法国多个地方的法国海军返回多客户户的法国海军返回多个地方
											</div>
										</td>
										<td>111</td>
										<td>6666.00</td>
										<td>100000</td>
										<td>
											<div class="input-group data-group">
		                                        <span class="previewbtn"><img src="__PUBLIC__/admin/images/imgGray.png" class="viewimg data-viewIcon" id="logo_img"/></span>
		                                        <input type="text" name="shop_logo"  class="form-control data-inp com-inp1 radius3 boxsizing" localrequired="">
		                                        <input type="file"  class="form-control" style="display: none;">
		                                        <span class="input-group-btn left">
		                                            <input type="button"  value="选择文件" class="upload-btn search-btn data-upBtn"/>
		                                        </span>
		                                    </div>
										</td>
										<td><i class="data-dele-icon"></i></td>
									</tr>
									<tr>
										<td>
											<span class="data-sort">4</span>
										</td>
										<td width="50" class="text-c">
											<a href="#">
												<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
											</a>
										</td>
										<td width="218" class="text-l">
											<div class="data-goods-det">
												几个客户的法国海军返回多客户几个客户的法国海军返回回多客军返回多个地方
											</div>
										</td>
										<td>111</td>
										<td>6666.00</td>
										<td>100000</td>
										<td>
											<div class="input-group data-group">
		                                        <span class="previewbtn"><img src="__PUBLIC__/admin/images/imgGray.png" class="viewimg data-viewIcon" id="logo_img"/></span>
		                                        <input type="text" name="shop_logo"  class="form-control data-inp com-inp1 radius3 boxsizing" localrequired="">
		                                        <input type="file"  class="form-control" style="display: none;">
		                                        <span class="input-group-btn left">
		                                            <input type="button"  value="选择文件" class="upload-btn search-btn data-upBtn"/>
		                                        </span>
		                                    </div>
										</td>
										<td><i class="data-dele-icon"></i></td>
									</tr>
									<tr>
										<td>
											<span class="data-sort">5</span>
										</td>
										<td width="50" class="text-c">
											<a href="#">
												<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
											</a>
										</td>
										<td width="218" class="text-l">
											<div class="data-goods-det">
												几个客户的法国海军返回多客户几
											</div>
										</td>
										<td>111</td>
										<td>6666.00</td>
										<td>100000</td>
										<td>
											<div class="input-group data-group">
		                                        <span class="previewbtn"><img src="__PUBLIC__/admin/images/imgGray.png" class="viewimg data-viewIcon" id="logo_img"/></span>
		                                        <input type="text" name="shop_logo"  class="form-control data-inp com-inp1 radius3 boxsizing" localrequired="">
		                                        <input type="file"  class="form-control" style="display: none;">
		                                        <span class="input-group-btn left">
		                                            <input type="button"  value="选择文件" class="upload-btn search-btn data-upBtn"/>
		                                        </span>
		                                    </div>
										</td>
										<td><i class="data-dele-icon"></i></td>
									</tr>
								</tbody>
							</table>
							<input type="button" value="添加商品" class="group-choice-btn"/>
							<!--<div class="data-operBox">
         						<div class="group-choice-again">
         							<p class="fight-pro-name data-pro-name"><a href="#">商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称商品名称</a></p>
         							<span class="data-operation">操作<i class="data-icon"></i></span>
         						</div>
         						<ul class="simulate-sele">
         							<li><a href="#">修改</a></li>
         							<li><a href="#">删除</a></li>
         						</ul>
         					</div>-->
							<p class="remind1 paddingB3">这是提示文字</p>
						</dd>
						<div class="clear"></div>
					</dl>
				</div>
				 <div class="btnbox3 boxsizing">
                    <a type="button" id="base_setting" class="btn1 radius3 marginT10 btn3-btnmargin">确认提交</a>
                    <a type="button" id="base_setting" class="btn1 radius3 marginT10">返回列表</a>
                </div>
			</div>
		</div>
		<!--内容结束-->
		<script type="text/javascript">
			function Rotate(){
				$('.data-operation').mouseenter(function(){
					$('.data-icon').addClass('jt-rotate');
					$(this).parent().next().show();
				});
				$('.simulate-sele').mouseleave(function(){
					//alert('鼠标离开下拉框');
					$(this).hide();
					$('.data-icon').removeClass('jt-rotate');
				});
				if($('.simulate-sele').is(":hidden")){
//					alert("显示");
					//$('.data-icon').removeClass('jt-rotate');

				} else {
//						alert("隐藏");
					
				}
			}
					
			Rotate();
		</script>

