		<div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
		<div class="iframeCon">
			<div class="white-shadow2">
				<div class="details-box">
					<h1 class="details-tit">下单/支付</h1>
					<table class="order-table">
						<tr>
							<td class="text-r" width="120">订单号</td>
							<td class="text-l" width="200">1534453453434153453</td>
							<td class="text-r" width="120">下单时间</td>
							<td class="text-l" width="200">2016-08-22&nbsp;00:00:00:00</td>
							<td class="text-r" width="120">支付方式</td>
							<td class="text-l" width="200">0345345345</td>
							<td></td>
						</tr>
						<tr>
							<td class="text-r" width="120">支付单号</td>
							<td class="text-l" width="200">1534453453434153453</td>
							<td class="text-r" width="120">支付时间</td>
							<td class="text-l" width="200">2016-08-22&nbsp;00:00:00:00</td>
							<td colspan="3"></td>
						</tr>
						<tr>
							<td class="text-r" width="120">支付日志</td>
							<td class="text-l" colspan="6">地方进口大量水分很大就开始发火的教快好看发火的教科书是多久发货的健康尽快恢复速度加快好看</td>
						</tr>
						<tr>
							<td class="text-r" width="120">订单取消原因</td>
							<td class="text-l" colspan="6">付款的两个季度付款了个jfk领导的经历jfk过来的反馈结果好地方健康更何况</td>
						</tr>
					</table>
					<h1 class="details-tit">购买/收货方信息</h1>
					<table class="order-table">
						<tr>
							<td class="text-r" width="120">买家</td>
							<td class="text-l" width="200">dhjkfhsdjkhfdjk</td>
							<td class="text-r" width="120">联系方式</td>
							<td class="text-l" width="200">15522036688</td>
							<td colspan="3"></td>
						</tr>
						<tr>
							<td class="text-r" width="120">收货地址</td>
							<td class="text-l" colspan="6">北京市北京市海淀区上地三街金隅嘉华大厦</td>
						</tr>
					</table>
					<h1 class="details-tit">发货信息</h1>
					<table class="order-table">
						<tr>
							<td class="text-r" width="120">发货时间</td>
							<td class="text-l" width="200">2016-08-22&nbsp;00:00:00:00</td>
							<td class="text-r" width="120">快递公司</td>
							<td class="text-l" width="200">快递快递快递</td>
							<td class="text-r" width="120">物流单号</td>
							<td class="text-l" width="200">0345454354345345</td>
							<td></td>
						</tr>
					</table>
					<h1 class="details-tit">商品信息</h1>
					<table class="order-table2">
						<tr>
							<th colspan="2" width="562">
								商品信息
							</th>
							<th width="158">单价</th>
							<th width="120">数量</th>
							<th width="197">优惠活动</th>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
						<tr>
							<td width="50" class="text-c">
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								<div class="order-goods-det">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>
								<p class="table-spec"><span>规格参数</span>￥8888X1件</p>
							</td>
							<td>6666.00</td>
							<td>6666</td>
							<td>满1000元减100元</td>
						</tr>
					</table>
					<div class="orderShow-foot">
						<p class="order-money">订单金额<span class="order-moneyNum orange-color">￥8888.00</span></p>
						<p class="order-freight">（运费<span>￥10.00</span>）</p>
					</div>
				</div>
			</div>
		</div>
