
	<head>
		<meta charset="UTF-8">
		<title>添加管理员</title>
		<link href="__PUBLIC__/css/reset.css" rel="stylesheet"/>
		<link href="__PUBLIC__/css/style.css" rel="stylesheet"/>
		<link href="__PUBLIC__/css/common.css" rel="stylesheet"/>
	</head>
		<div class="content">
			<div class="jurisdiction">
				<dl class="juris-dl boxsizing">
					<dt class="left text-r boxsizing"><span class="redstar">*</span>登录名：</dt>
					<dd class="left text-l">
						<input type="text" class="com-inp1 radius3 boxsizing"/>
						<p class="remind1">这是提示文字</p>
					</dd>
				</dl>
				<dl class="juris-dl boxsizing">
					<dt class="left text-r boxsizing"><span class="redstar">*</span>密码：</dt>
					<dd class="left text-l">
						<input type="text" class="com-inp1 radius3 boxsizing"/>
						<p class="remind1">这是提示文字</p>
					</dd>
				</dl>
				<dl class="juris-dl boxsizing">
					<dt class="left text-r boxsizing"><span class="redstar">*</span>确认密码：</dt>
					<dd class="left text-l">
						<input type="text" class="com-inp1 radius3 boxsizing"/>
						<p class="remind1">这是提示文字</p>
					</dd>
				</dl>
				<dl class="juris-dl boxsizing">
					<dt class="left text-r boxsizing"><span class="redstar">*</span>权限组：</dt>
					<dd class="left text-l">
						<select class="com-sele radius3 juris-dl-sele">
							<option>权限一</option>
							<option>权限二</option>
							<option>权限三</option>
							<option>权限四</option>
						</select>
						<p class="remind1">这是提示文字</p>
					</dd>
				</dl>
			</div>
			<div class="btnbox3">
				<a class="btn1 radius3 footbtn">确认提交</a>
				<a class="btn1 radius3 footbtn">返回列表</a>
			</div>
		</div>
		
		
		<script type="text/javascript" src="__PUBLIC__/js/jquery.min.js"></script>
		<script type="text/javascript" src="__PUBLIC__/js/common2.js"></script>

