	<div class="icon-alert">
		<h1 class="details-tit icon-alert-tit">选择商品<i class="alert-close"></i></h1>
		<!--<div class="type-box">
			<p class="icon-type">类型</p>
			<ul class="icon-type-list">
				<li><a href="#">全部</a></li>
				<li><a href="#">常规</a></li>
				<li><a href="#">购物</a></li>
				<li><a href="#">交通</a></li>
				<li><a href="#">食物</a></li>
				<li><a href="#">娱乐</a></li>
				<li><a href="#">美妆</a></li>
			</ul>
		</div>-->
		<div class="group-choice-classify">
			<p class="group-classify-tit">商品分类</p>
			<select name="" id="" class="group-sele">
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
			</select>
			<select name="" id="" class="group-sele">
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
				<option value="">请选择商品分类</option>
			</select>
			<input type="text" class="com-inp1 group-inp" placeholder="输入商品名称或SKU编号"/>
			<input type="button" value="查询" class="group-choice-btn group-search-btn"/>
		</div>
		<ul class="icon-list fight-icon-list">
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品名称商品名名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品名称商品商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品名称商品品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称名称称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品名称商品名称名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名品名称商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品名商品商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名名称商品名称商品名称</p>
				</a>
			</li>
			<li>
				<a href="#">
					<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="icon-img"/>
					<p class="icon-name">商品名称商品名称商品名称商品称</p>
				</a>
			</li>
		</ul>
		<div class="pagination boxsizing icon-page">
			<ul class="page-list">
				<li class="first-pagenation"><i class="first-icon"></i></li>
				<li class="prev-pagenation"><i class="prev-icon"></i></li>
				<li class="now-pagenation"><input type="text" value="1" class="now-inp radius3"/></li>
				<li class="all-pagenation">6页</li>
				<li class="next-pagenation"><i class="next-icon"></i></li>
				<li class="last-pagenation"><i class="last-icon"></li>
			</ul>
		</div>
		<div class="btn-box-center">
			<input type="button" class="btn1 radius3" value="确认">
			
		</div>
	</div>
	<div class="icon-cover"></div>
	


<script type="text/javascript">
	$(function(){
		$('.icon-type-list li a').bind('click',function(){
			 $(this).addClass("green-font2").parent().siblings().find("a").removeClass("green-font2"); 
		});
		$('.icon-list li').bind('click',function(){
			$(this).addClass('green-border');
			var	typeIcon = "<i class='type-icon'></i>";
			$(this).children('a').append(typeIcon);
			$(this).siblings().find('.type-icon').remove();
			$(this).siblings().removeClass('green-border');
		});
		$('.alert-close').bind('click',function(){
			$(this).parents('.icon-alert').hide();
			$('.icon-cover').hide();
		})
	})
</script>