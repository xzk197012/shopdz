
		<div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
		<div class="iframeCon">
			<div class="white-bg text-c">
				<div class="coupon-con">
					<div class="coupon-left">
						<div class="phoneH">
							<h2 class="phone-tit">ShopDZ商城</h2>
						</div>
						<div class="coupon-box sc-coupon">
							<div class="coupon-box-det sc-coupon-det">
								<div class="coupon-box-top">
									<div class="coupon-top-con">
										<div class="zoom">
											<p class="coupon-subtit left">优惠券活动标题</p>
											<p class="count-limit right">每人限领<span>10</span>张</p>
										</div>	
										<div class="zoom couponMoney-box">
											<div class="left">
												<span class="money-unit">¥</span>
												<span class="money-num">1000.00</span>
											</div>
											<div class="right">
												<!--<input type="button" value="分享" class="coupon-share"/>-->
												<!--<p class="coupon-share">分享</p>-->
												<img src="__PUBLIC__/admin/images/sc_statu.png" alt="" class="coupon-statu"/>
											</div>
										</div>
									</div>
								</div>
								<div class="coupon-box-bottom">
									<p class="coupon-bottom-tit">订单满300元（含运费）</p>
									<p class="coupon-remind2">有效期：2016.12.12-2016.12.12</p>
								</div>
								<p class="coupon-word">微信卡券包</p>
							</div>
							<span class="left-circles coupon-circles"></span>
							<span class="right-circles coupon-circles"></span>
						</div>
						
						<div class="coupon-box wx-coupon">
							<div class="coupon-box-det wx-coupon-det">
								<div class="coupon-box-top">
									<div class="coupon-top-con">
										<div class="zoom">
											<p class="coupon-subtit left">优惠券活动标题</p>
											<p class="count-limit right">每人限领<span>10</span>张</p>
										</div>	
										<div class="zoom couponMoney-box">
											<div class="left">
												<span class="money-unit">¥</span>
												<span class="money-num">1000.00</span>
											</div>
											<div class="right">
												<!--<input type="button" value="分享" class="coupon-share"/>-->
												<img src="__PUBLIC__/admin/images/wx_statu.png" alt="" class="coupon-statu"/>
											</div>
										</div>
									</div>
								</div>
								<div class="coupon-box-bottom">
									<p class="coupon-bottom-tit">订单满300元（含运费）</p>
									<p class="coupon-remind2">有效期：2016.12.12-2016.12.12</p>
								</div>
								<p class="coupon-word">SHOPDZ商城优惠券</p>
							</div>
							<span class="left-circles coupon-circles"></span>
							<span class="right-circles coupon-circles"></span>
						</div>
					</div>
					<div class="coupon-right">
			             <div class="couponR-con">
			             	<div class="coupon-edit-box">
			             		<h1 class="soupon-edit-tit">优惠券基础信息</h1>
			             		<table class="coupon-table">
			             			<tr>
			             				<td width="100">优惠券名称</td>
			             				<td><input type="text" class="coupon-inp" placeholder="请输入物流单号"/></td>
			             			</tr>
			             			<tr>
			             				<td>发放总量</td>
			             				<td>
			             					<div class="release-price coupon-table-num">
												<input type="text" class="price-inp left"/>
												<span class="price-unit left">张</span>
											</div>
										</td>
			             			</tr>
			             			<tr>
			             				<td>面值</td>
			             				<td>
			             					<div class="release-price coupon-table-num">
												<input type="text" class="price-inp left"/>
												<span class="price-unit left">元</span>
											</div>
			             				</td>
			             			</tr>
			             			<tr>
			             				<td>订单金额</td>
			             				<td>
			             					<div class="coupon-full">
			             						<span class="left">满</span>
				             					<div class="release-price coupon-table-num left full-num">
													<input type="text" class="price-inp left"/>
													<span class="price-unit left">元</span>
												</div>
												<span class="left">可使用</span>
			             					</div>
			             					
			             				</td>
			             			</tr>
			             			<tr>
			             				<td>卡券颜色</td>
			             				<td class="posiR">
			             					<p class="color-click"><span class="color-span"></span><span class="color-click-span"><i class="color-icon"></i></span></p>
			             					<div class="color-show-box">
			             						<ul class="color-show-list">
			             							<li class="color-63b359" name="Color010" value="#63b359"></li>
			             							<li class="color-2c9f67" name="Color010" value="#2c9f67"></li>
			             							<li class="color-509fc9" name="Color010" value="#509fc9"></li>
			             							<li class="color-5885cf" name="Color010" value="#5885cf"></li>
			             							<li class="color-9062c0" name="Color010" value="#9062c0"></li>
			             							<li class="color-d09a45" name="Color010" value="#d09a45"></li>
			             							<li class="color-e4b138" name="Color010" value="#e4b138"></li>
			             							<li class="color-ee903c" name="Color010" value="#ee903c"></li>
			             							<li class="color-dd6549" name="Color010" value="#dd6549"></li>
			             							<li class="color-cc463d" name="Color100" value="#cc463d"></li>
			             						</ul>
			             					</div>
			             				</td>
			             			</tr>
			             			<tr>
			             				<td class="alignT2 relativeT5">同步发布至</td>
			             				<td>
			             					<div class="button-holder coupon-holder marginT5">
												<p class="radiobox"><input type="radio" id="radio-1-5" name="radio-1-set" class="regular-radio" checked="checked"><label for="radio-1-5"></label><span class="radio-word radio-word-black">微信卡券（包）</span></p>
											</div>
											<p class="coupon-remind">这里是提示文字这里是提示文字这里是提示文字这里是提示文字这里是提示文字这里是提示文字这里是提示文字</p>
			             				</td>
			             			</tr>
			             			
			             		</table>
			             		<h1 class="soupon-edit-tit">基本规则</h1>
			             		<table class="coupon-table">
			             			<tr>
			             				<td width="100">每人限领</td>
			             				<td>
			             					<!--<select class="coupon-sele">
			             						<option>不限张</option>
			             						<option>不限张</option>
			             						<option>不限张</option>
			             						<option>不限张</option>
			             						<option>不限张</option>
			             						<option>不限张</option>
			             					</select>-->
			             					<input type="text" class="coupon-inp"/><span class="tips-tag" tips="提示1提示提示提示提示提示"><i class="tips-icon"></i></span>
			             				</td>
			             			</tr>
			             			
			             			<tr>
			             				<td>生效时间</td>
			             				<td>
			             					<p class="time-box coupon-time-box"><input type="text" class="coupon-inp hasDatepicker" id="ostime" name="stime" readonly=""><i class="timeinp-icon"></i></p>
			             					<span class="tips-tag" tips="提示2提示提示提示提示提示"><i class="tips-icon"></i></span>
			             				</td>
			             			</tr>
			             			<tr>
			             				<td>过期时间</td>
			             				<td>
			             					<p class="time-box coupon-time-box"><input type="text" class="coupon-inp hasDatepicker" id="ostime" name="stime" readonly=""><i class="timeinp-icon"></i></p>
			             					<span class="tips-tag" tips="提示3提示提示提示提示提示"><i class="tips-icon"></i></span>
			             				</td>
			             			</tr>
			             			<tr>
			             				<td>兑换积分</td>
			             				<td>
			             					<input type="text" class="coupon-inp"
			             					/><span class="tips-tag" tips="提示4提示提示提示提示提示"><i class="tips-icon"></i></span>
			             				</td>
			             			</tr>
			             			<tr>
			             				<td class="alignT2 relativeT5">推广设置</td>
			             				<td>
			             					<div class="button-holder coupon-holder marginT5">
												<p class="radiobox"><input type="radio" id="radio-1-6" name="radio-1-set" class="regular-radio" checked="checked"><label for="radio-1-6"></label><span class="radio-word radio-word-black">允许分享领取链接</span></p>
											</div>
											<p class="coupon-remind">这里是提示文字这里是提示文字这里是提示文字这里是提示文字这里是提示文字这里是提示文字这里是提示文字</p>
			             				</td>
			             			</tr>
			             			<tr>
			             				<td>状态</td>
			             				<td>
			             					<div class="button-holder coupon-holder">
												<p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-7" name="radio-1-set" class="regular-radio" checked="checked"><label for="radio-1-7"></label><span class="radio-word radio-word-black">开启</span></p>
												<p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-8" name="radio-1-set" class="regular-radio" checked="checked"><label for="radio-1-8"></label><span class="radio-word radio-word-black">关闭</span></p>
											</div>
											<span class="tips-tag" tips="提示5提示提示提示提示提示提示提示提示提示提示提示"><i class="tips-icon top0"></i></span>
			             				</td>
			             			</tr>
			             		</table>
			             	</div>
			             	
			             </div>
			             <s>
			                <i class="bg-jt"></i>
			            </s>
					</div>
				</div>
				<div class="btn-box-center borderT-none">
					<input type="button" class="btn1 radius3" value="确认提交">
					<input type="button" class="btn1 radius3 marginL5" value="返回列表">
				</div>
			</div>
		</div>



<script type="text/javascript">
$(function(){
	$('.color-click-span').bind('click',function(){
		$(this).children('i').toggleClass('color-active');
		$('.color-show-box').toggle();
	});
	$('.color-span').css('background','#63b359');
	$('.color-show-list li').bind('click',function(){
		var color=$(this).attr("value");
		//alert(color);
		$('.color-show-box').hide();
		$('.color-click-span').children('i').removeClass('color-active');
		$('.color-span').css('background',color);
		$('.coupon-box-top').css('background',color);
	});
	$('.couponR-con span.tips-tag').each(function() {
		var _this = this;
		$(_this).bind(
			{
				mousemove:function(){
					e=arguments.callee.caller.arguments[0] || window.event; 
					tip = $(_this).attr('tips');
					remindNeed($(_this),e,tip);
				},
				mouseout:function() {
					$('.tip-remind').remove();
				}
			}
		);
	});
})
	
</script>