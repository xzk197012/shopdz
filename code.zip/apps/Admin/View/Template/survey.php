		
		<ul class="survey-tit">
			<li class="gross-box gross-income">
				<h6 class="gross-tit">总收入</h6>
				<p class="gross-num">8888</p>
				<div class="gross-con">近30天下单金额&nbsp;88888</div>
			</li>
			<li class="gross-box gross-order">
				<h6 class="gross-tit">总订单数</h6>
				<p class="gross-num">8888</p>
				<div class="gross-con">近30天下单金额&nbsp;111111</div>
			</li>
			<li class="gross-box gross-member">
				<h6 class="gross-tit">总下单会员数</h6>
				<p class="gross-num">8888</p>
				<div class="gross-con">近30天下单会员数&nbsp;6666</div>
			</li>
			<li class="gross-box  gross-member2">
				<h6 class="gross-tit">总下单会员数</h6>
				<p class="gross-num">8888</p>
				<div class="gross-con">近30天下单会员数&nbsp;2222</div>
			</li>
		</ul>
		
		<div class="iframeCon surveyIframe">
			<ul class="transverse-nav">
				<li class="activeFour"><a href="javascript:;"><span>下单金额</span></a></li>
				<li><a href="javascript:;"><span>下单数量</span></a></li>
				<li><a href="javascript:;"><span>下单会员</span></a></li>
				<li><a href="javascript:;"><span>新增会员</span></a></li>
			</ul>
			<div class="survey-topcon">
				<div class="tab-conbox">
					<div class="top-con radius5 white-shadow2 left">
						<h2 class="top-tit boxsizing left-toptit">
							<p class="main-tit">单品销售排名</p>
							<p class="sub-tit">掌握30日内最热销的商品及时补货</p>
							<span class="top-span left-topspan">TOP10</span>
						</h2>
						<table class="survey-table">
							<tr>
								<th width="65">排名</th>
								<th colspan="2">
									商品信息
								</th>
								<th width="90">销量</th>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#" class="goods-det">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
						</table>
					</div>
					<div class="top-con radius5 white-shadow2 left">
						<h2 class="top-tit boxsizing right-toptit">
							<p class="main-tit">单品销售排名</p>
							<p class="sub-tit">掌握30日内最热销的商品及时补货</p>
							<span class="top-span right-topspan">TOP10</span>
						</h2>
						<table class="survey-table">
							<tr>
								<th width="65">排名</th>
								<th colspan="2">
									商品信息
								</th>
								<th width="90">销量</th>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#" class="goods-det">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
							<tr>
								<td>1</td>
								<td width="60">
									<a href="#">
										<img src="../images/picbg.png" alt="" class="goodsImg"/>
									</a>
								</td>
								<td class="text-l">
									<a href="#" class="goods-det">
										几个客户的法国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多客户的法国海军返回多个地方
									</a>
								</td>
								<td>6666</td>
							</tr>
						</table>
					</div>
					
				</div>
				<div class="tab-conbox">
					
					
					
				</div>
				<div class="tab-conbox">
					
					
					
				</div>
				<div class="tab-conbox">
					
					
					
				</div>
			</div>
		</div>
		<script type="text/javascript">
			$(function(){
				//添加会员提示
				$('.add-li').mousemove(function(){
					e=arguments.callee.caller.arguments[0] || window.event; 
					remindNeed($('.add-li'),e,'添加会员');
				})
				$('.add-li').mouseout(function(){
			     	$('.tip-remind').remove();
			    });
				$('.refresh-li').mousemove(function(){
					e=arguments.callee.caller.arguments[0] || window.event; 
					remindNeed($('.refresh-li'),e,'刷新');
				})
				$('.refresh-li').mouseout(function(){
			     	$('.tip-remind').remove();
			    });
			    $('.export-li').mousemove(function(){
					e=arguments.callee.caller.arguments[0] || window.event; 
					remindNeed($('.export-li'),e,'导出');
				})
				$('.export-li').mouseout(function(){
			     	$('.tip-remind').remove();
			    });
			    $('.dele-li').mousemove(function(){
					e=arguments.callee.caller.arguments[0] || window.event; 
					remindNeed($('.dele-li'),e,'批量删除');
				})
				$('.dele-li').mouseout(function(){
			     	$('.tip-remind').remove();
			    });
			    $('.back-li').mousemove(function(){
					e=arguments.callee.caller.arguments[0] || window.event; 
					remindNeed($('.back-li'),e,'返回');
				})
				$('.back-li').mouseout(function(){
			     	$('.tip-remind').remove();
			    });
			})
		</script>