		<div class="cover"></div>
		<div class="alert showAlert radius3 addSpec-alert specialAlert">
			<i class="close-icon"></i>
			<h1 class="special-tit">添加规格值</h1>
			<div class="special-con addSpec-con">
				<span class="special-con-left left">规格值</span>
				<input type="text" class="com-inp1 radius3 boxsizing left">
				<div class="clear"></div>
				<p class="special-remind">请输入规格名称</p>
			</div>
			<div class="alert-btnbox boxsizing">
				<a class="btn1 radius3">确认</a>
			</div>
		</div>