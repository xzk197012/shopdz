		<div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
		<div class="iframeCon">
			<div class="white-shadow2">
				<div class="zoom">
					<div class="manage-left left">
						<h1 class="details-tit">商品信息</h1>
						<ul class="manage-left-con">
							<li>
								<div class="img-cover"></div>
								<div class="edit-btn1"><a href='javascript:delItem("{$key}");'>删除</a></div>
								<div class="manage-picbox"><img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="manage-pic"/></div>
								<p class="manage-name ellipsis">商品名称商品名称商品名称商品名称</p>
								<p class="manage-price">￥998.00</p>
							</li>
							<li>
								<div class="img-cover"></div>
								<div class="edit-btn1"><a href='javascript:delItem("{$key}");'>删除</a></div>
								<div class="manage-picbox"><img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="manage-pic"/></div>
								<p class="manage-name ellipsis">商品名称商品名称商品名称商品名称</p>
								<p class="manage-price">￥998.00</p>
							</li>
							<li>
								<div class="img-cover"></div>
								<div class="edit-btn1"><a href='javascript:delItem("{$key}");'>删除</a></div>
								<div class="manage-picbox"><img src="__PUBLIC__/admin/images/loginbg.jpg" alt="" class="manage-pic"/></div>
								<p class="manage-name ellipsis">商品名称商品名称商品名称商品名称</p>
								<p class="manage-price">￥998.00</p>
							</li>
							<li>
								<div class="img-cover"></div>
								<div class="edit-btn1"><a href='javascript:delItem("{$key}");'>删除</a></div>
								<div class="manage-picbox"><img src="__PUBLIC__/admin/images/picbg.png" class="manage-picbg"/></div>
								<p class="manage-name ellipsis">商品名称商品名称商品名称商品名称</p>
								<p class="manage-price">￥998.00</p>
							</li>
						</ul>
					</div>
					<div class="manage-right left">
						<p class="manange-right-tit">选择商品添加</p>
						<p class="pro-keyword">商品关键字</p>
						<div class="manage-search">
							<input type="text" class="com-inp1 manage-inp left"/>
							<button type="submit" class="search-btn left radius3">搜索</button>
						</div>
						<ul class="manage-pro-list">
							<li>
								<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="manage-pro-img left"/>
								<div class="manage-pro-con right">
									<p class="manage-pro-name">商品名称商品名称商品名称商品名称商品名称商品名称商品名称</p>
									<p class="zoom"><span class="manage-pro-price left">￥998.00</span><button type="button" class="search-btn radius3 manage-pro-btn right">添加</button></p>
								</div>
							</li>
							<li>
								<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="manage-pro-img left"/>
								<div class="manage-pro-con right">
									<p class="manage-pro-name">商品名称商品名称商品名名称</p>
									<p class="zoom"><span class="manage-pro-price left">￥998.00</span><button type="button" class="search-btn radius3 manage-pro-btn right">添加</button></p>
								</div>
							</li>
							<li>
								<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="manage-pro-img left"/>
								<div class="manage-pro-con right">
									<p class="manage-pro-name">商品名称商品名称商品名称商品名称商品名称商品名称商品名称</p>
									<p class="zoom"><span class="manage-pro-price left">￥998.00</span><button type="button" class="search-btn radius3 manage-pro-btn right">添加</button></p>
								</div>
							</li>
							<li>
								<img src="__PUBLIC__/admin/images/picbg.png" alt="" class="manage-pro-img left"/>
								<div class="manage-pro-con right">
									<p class="manage-pro-name">商品名称商品名称商品名称商商品名称</p>
									<p class="zoom"><span class="manage-pro-price left">￥998.00</span><button type="button" class="search-btn radius3 manage-pro-btn right">添加</button></p>
								</div>
							</li>
						</ul>
						<div class="pagination boxsizing">
							<ul class="page-list">
								<li class="first-pagenation"><i class="first-icon"></i></li>
								<li class="prev-pagenation"><i class="prev-icon"></i></li>
								<li class="now-pagenation"><input type="text" value="1" class="now-inp radius3"/></li>
								<li class="all-pagenation">6页</li>
								<li class="next-pagenation"><i class="next-icon"></i></li>
								<li class="last-pagenation"><i class="last-icon"></li>
							</ul>
						</div>
					</div>
				</div>
				 <div class="manege-btnbox">
                    <a class="btn1 radius3 marginT10 btn3-btnmargin normal">确认提交</a>
                    <a class="btn1 radius3 marginT10 normal">返回上页</a>
                </div>
			</div>
		</div>
