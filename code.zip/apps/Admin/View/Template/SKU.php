
<link href="__PUBLIC__/css/reset.css" rel="stylesheet"/>
<link href="__PUBLIC__/css/common.css" rel="stylesheet"/>
<link href="__PUBLIC__/css/style.css" rel="stylesheet"/>
<style type="text/css">
	.spec_table {
	    background-color: #FFF;
	    width: 98%;
	    margin: 10px auto;
	    border: solid 1px #BCE8F1;
	    box-shadow: 3px 3px 0 rgba(153,153,153,0.15);
	}

</style>



<ul class="SKU-box">
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
	<li class="sku-li left boxsizing">
		<dl class="sku-child">
			<dt class="sku-child-dt">
				<img src="../../static/img/SKU1.jpg" class="sku-child-img"/>
			</dt>
			<dd class="sku-child-dd">
				<ul class="sku-child-det">
					<li class="boxsizing">SKU：<p class="det-data sku-col">13262315615644654</p></li>
					<li class="boxsizing">价格：<p class="det-data price-col">1233120.00元</p></li>
					<li class="boxsizing">库存：<p class="det-data num-col">156031321</p></li>
					<li class="boxsizing">货号：<p class="det-data">13264653264654</p></li>
					<li class="boxsizing det-lastli">
						<p class="left">规格：</p>
						<ul class="left lastli-secondul">
							<li>36码码码码码码码码</li>
							<li>红红色红色红色红色红色色</li>
							<li>0.1ml-500ml</li>
						</ul>
					</li>
				</ul>
			</dd>
		</dl>
	</li>
</ul>




<table border="0" cellpadding="0" cellspacing="0" class="spec_table">
	<thead>
		<tr>
			<th>颜色</th>
			<th>种类</th>
			<th>
				<span class="redstar"></span>价格
				<div class="batch">
					<i class="icon-edit" title="批量操作"></i>
					<div class="batch-input">
	                    <h6>批量设置价格：</h6>
	                    <a href="javascript:void(0)" class="closebtn3">X</a>
	                    <input name="" type="text" class="text price posi2">
	                    <a href="javascript:void(0)" class="btn2 search-btn radius3" data-type="marketprice">设置</a>
	                    <span class="arrow"></span>
	                </div>
				</div>
			</th>
			<th>
				<span class="redstar"></span>库存
				<div class="batch">
					<i class="icon-edit" title="批量操作"></i>
					<div class="batch-input">
	                    <h6>批量设置价格：</h6>
	                    <a href="javascript:void(0)" class="closebtn3">X</a>
	                    <input name="" type="text" class="text price posi2">
	                    <a href="javascript:void(0)" class="btn2 search-btn radius3" data-type="marketprice">设置</a>
	                    <span class="arrow"></span>
	                </div>
				</div>
			</th>
			<th>商家货号</th>
			<th>
				<span class="redstar"></span>图片
				<div class="batch">
					<i class="icon-edit" title="批量操作"></i>
					<div class="batch-input" style="left: -110px;">
	                    <h6 class="banch-inp-h">批量设置价格：</h6>
	                    <a href="javascript:void(0)" class="closebtn3">X</a>
	                    <!--<input name="" type="text" class="text price posi2">-->
	                    <div class="file-box2 left">
		                	<input type="text" class="com-inp1 table-file">
		                	<span class="upload-span">
		                		<input type="file" class="upload-file">
		                		<input type="button" value="批量上传" class="btn2 test-btn com-btn1 upload-btn1">
		                	</span>
		                </div>	
	                    <a href="javascript:void(0)" class="btn2 search-btn radius3 right batch-btn1" data-type="marketprice">保存</a>
	                    <span class="arrow"></span>
	                </div>
				</div></th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td>茶色</td>
			<td>官方标配</td>
			<td>
				<input class="text price" type="text" name="spec[i_181182][marketprice]" data_type="marketprice" nc_type="i_181182|marketprice" value="">
				<span class="add-on">元</span>
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp" type="text" placeholder="0">
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp2" type="text" placeholder="0">
			</td>
			<td>
                <div class="file-box2">
                	<input type="text" class="com-inp1 table-file"/>
                	<span class="upload-span">
                		<input type="file" class="upload-file"/>
                		<input type="button" value="上传图片" class="btn-white com-btn1 upload-btn1"/>
                	</span>
                </div>
			</td>
		</tr>
		<tr>
			<td>茶色</td>
			<td>官方标配</td>
			<td>
				<input class="text price" type="text" name="spec[i_181182][marketprice]" data_type="marketprice" nc_type="i_181182|marketprice" value="">
				<span class="add-on">元</span>
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp" type="text" placeholder="0">
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp2" type="text" placeholder="0">
			</td>
			<td>
                <div class="file-box2">
                	<input type="text" class="com-inp1"/>
                	<span class="upload-span">
                		<input type="file" class="upload-file"/>
                		<input type="button" value="上传图片" class="btn-white com-btn1 upload-btn1"/>
                	</span>
                </div>
			</td>
		</tr>
		<tr>
			<td>茶色</td>
			<td>官方标配</td>
			<td>
				<input class="text price" type="text" name="spec[i_181182][marketprice]" data_type="marketprice" nc_type="i_181182|marketprice" value="">
				<span class="add-on">元</span>
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp" type="text" placeholder="0">
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp2" type="text" placeholder="0">
			</td>
			<td>
                <div class="file-box2">
                	<input type="text" class="com-inp1"/>
                	<span class="upload-span">
                		<input type="file" class="upload-file"/>
                		<input type="button" value="上传图片" class="btn-white com-btn1 upload-btn1"/>
                	</span>
                </div>
			</td>
		</tr>
		<tr>
			<td>茶色</td>
			<td>官方标配</td>
			<td>
				<input class="text price" type="text" name="spec[i_181182][marketprice]" data_type="marketprice" nc_type="i_181182|marketprice" value="">
				<span class="add-on">元</span>
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp" type="text" placeholder="0">
			</td>
			<td>
				<input class="text stock valid boxsizing table-inp2" type="text" placeholder="0">
			</td>
			<td>
                <div class="file-box2">
                	<input type="text" class="com-inp1"/>
                	<span class="upload-span">
                		<input type="file" class="upload-file"/>
                		<input type="button" value="上传图片" class="btn-white com-btn1 upload-btn1"/>
                	</span>
                </div>
			</td>
		</tr>
	</tbody>
</table>

<script type="text/javascript">
	$(function(){
		//显示
		$('.icon-edit').click(function(){
			$(this).next('.batch-input').show();
		})
		//关闭
		$('.closebtn3').click(function(){
			$(this).parents('.batch-input').hide();
		})
	})
</script>






















