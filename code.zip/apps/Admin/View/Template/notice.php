		<div class="cover"></div>
		<div class="alert itemAlert radius3">
			<h1 class="items-tit boxsizing">待处理事项</h1>
			<i class="close-icon"></i>
			<ul class="item-list">
				<li>
					<span class="category-tit left">会员</span>
					<span class="category-con left"><a href="#" class="list-num">1</a>预存款提现申请</span>
				</li>
				<li>
					<span class="category-tit left">会员</span>
					<span class="category-con left"><a href="#" class="list-num">1</a>预存款提现申请</span>
				</li>
				<li>
					<span class="category-tit left">会员</span>
					<span class="category-con left"><a href="#" class="list-num">1</a>预存款提现申请</span>
				</li>
			</ul>
		</div>