		<div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
		<div class="iframeCon">
			<div class="white-shadow2">
				<div class="details-box">
					<h1 class="details-tit">收货信息</h1>
					<table class="order-table">
						<tr>
							<td class="text-r" width="120">收货人</td>
							<td class="text-l">dhjkfhsdjkhfdjk</td>
						</tr>
						<tr>
							<td class="text-r" width="120">联系方式</td>
							<td class="text-l">15522036688</td>
						</tr>
						<tr>
							<td class="text-r" width="120">收货地址</td>
							<td class="text-l">北京市北京市海淀区上地三街金隅嘉华大厦</td>
						</tr>
					</table>
					<h1 class="details-tit">物流动态</h1>
					<table class="order-table">
						<tr>
							<td class="text-r" width="120">快递公司</td>
							<td class="text-l" width="200">快递快递快递</td>
							<td class="text-r" width="120">物流单号</td>
							<td class="text-l" width="200">0345454354345345</td>
							<td class="text-r" width="120">发货时间</td>
							<td class="text-l" width="200">2016-08-22&nbsp;00:00:00:00</td>
							<td></td>
						</tr>
						<tr>
							<td class="text-r" width="120">发货信息</td>
							<td class="text-l" colspan="6">这里是留言这里是留言这里是留言这里是留言这里是留言这里是留言</td>
						</tr>
					</table>
					<div class="logistics-det-box">
						<ul class="status-list">
							<li>
								<span class="left status-time">2016-08-08&nbsp;00:00:00</span>
								<p class="left">物流动态信息物流动态信息物流动态物物流动态态信物流动态信息物流动态信息物流动态信息物流动态物流动态信息物流动态信息流动态信息物流动态信息</p>
							</li>
							<li>
								<span class="left status-time">2016-08-08&nbsp;00:00:00</span>
								<p class="left">物流动态信息态动态信息</p>
							</li>
							<li>
								<span class="left status-time">2016-08-08&nbsp;00:00:00</span>
								<p class="left">物流动态信息物流动态信息物流动态物物流动动态信息物流息流动态信息物流动态信息</p>
							</li>
							<li>
								<span class="left status-time">2016-08-08&nbsp;00:00:00</span>
								<p class="left">物流动物流动态信动态信息物流动态信息流动态信息物流动态信息</p>
							</li>
							<li>
								<span class="left status-time">2016-08-08&nbsp;00:00:00</span>
								<p class="left">物流动态物流动态信态动态信态信息物流动态信息</p>
							</li>
							<li>
								<span class="left status-time">2016-08-08&nbsp;00:00:00</span>
								<p class="left">物流动态信息物流动态信息物流动态物信息物流动态物流动态信息物流动态信息流动态信息物流动态信息</p>
							</li>
						</ul>
					</div>
					<h1 class="details-tit">商品信息</h1>
					<table class="order-table">
						<tr>
							<td class="text-r" width="120">订单编号</td>
							<td class="text-l" width="200">0345454354345345</td>
							<td class="text-r" width="120">订单总额</td>
							<td class="text-l" width="200">￥888.88</td>
							<td class="text-r" width="120">订单运费</td>
							<td class="text-l" width="200">￥888.88</td>
							<td></td>
						</tr>
						<tr>
							<td class="text-r" width="120">支付方式</td>
							<td class="text-l" width="200">货到付款</td>
							<td class="text-r" width="120">下单时间</td>
							<td class="text-l" width="200">2016-08-08&nbsp;00:00:00</td>
							<td class="text-r" width="120">完成时间</td>
							<td class="text-l" width="200">2016-08-08&nbsp;00:00:00</td>
							<td></td>
						</tr>
						
					</table>
					<table class="order-table2 logistic-table">
						<tr>
							<th width="50px"></th>
							<th>
								商品信息
							</th>
							<th width="158px">单价</th>
							<th width="120px">数量</th>
						</tr>
						<tr>
							<td>
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a></td>
							<td class="text-l">
								<!--<div class="order-goods-det logistics-pro">
									几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
								</div>-->
								客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方
								<p class="table-spec"><span>规格参数</span></p>
							</td>
							<td width="100">6666.00</td>
							<td width="200">6666.00</td>
						</tr>
						<tr>
							<td>
								<a href="#">
									<img src="../images/picbg.png" alt="" class="order-goodsImg"/>
								</a>
							</td>
							<td class="text-l">
								客户的法国海军返回多客户几多个地方
								<p class="table-spec"><span>规格参数</span></p>
							</td>
							<td width="100">6666.00</td>
							<td width="200">6666.00</td>
						</tr>
					</table>
				</div>
			</div>
		</div>
