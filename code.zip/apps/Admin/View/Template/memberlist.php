
	<head>
		<meta charset="utf-8" />
		<title>权限管理</title>
		<link rel="stylesheet" href="__PUBLIC__/css/bootstrap.min.css" />
  		<link rel="stylesheet" href="__PUBLIC__/css/style.min862f.css" />
  		<link href="__PUBLIC__/css/plugins/switchery/switchery.css" rel="stylesheet">
		<link href="__PUBLIC__/css/reset.css" rel="stylesheet"/>
		<link href="__PUBLIC__/css/style.css" rel="stylesheet"/>
		<link href="__PUBLIC__/css/common.css" rel="stylesheet"/>
		<style type="text/css">
		.onoffswitch {
		    position: relative;
		    width: 54px;
		    -webkit-user-select: none;
		    -moz-user-select: none;
		    -ms-user-select: none;
		    text-align: center;
		    margin: 0 auto;
		}
			.onoffswitch-inner::before {
			    content: "ON";
			    /*padding-left:-5px !important;*/
			   position: relative;
			   left: -10px;
			    background-color: rgb(26, 179, 148);
			    color: rgb(255, 255, 255);
			}
			
			
		</style>
	</head>
		<div class="content">
			<div class="tablebox1">
				<div class="table-tit">
					<h1 class="tabtit1 left">管理员列表</h1>
					<div class="btnbox1 right">
						<a class="btn1 radius3 btn-margin">添加管理员</a>
					</div>
				</div>
				<table class="tablelist1">
					<tr>
						<th style="width:20%;">管理员</th>
						<th style="width:20%;">权限组</th>
						<th style="width:20%;">上次登录时间</th>
						<th style="width:20%;">IP</th>
						<th style="width:20%;">操作</th>
						
					</tr>
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<div class="icon-box-com">
								<div class="icon-box left">
									<a class="fontface3 fa-edit icon-img" title="编辑"></a>
								</div>
								<div class="icon-box left">
									<a class="fontface3 fa-trash-o icon-img" title="删除"></a>
								</div>
							</div>
						</td>
					</tr>
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<div class="icon-box-com">
								<div class="icon-box left">
									<a class="fontface3 fa-edit icon-img" title="编辑"></a>
								</div>
								<div class="icon-box left">
									<a class="fontface3 fa-trash-o icon-img" title="删除"></a>
								</div>
							</div>
						</td>
					</tr>
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<div class="icon-box-com">
								<div class="icon-box left">
									<a class="fontface3 fa-edit icon-img" title="编辑"></a>
								</div>
								<div class="icon-box left">
									<a class="fontface3 fa-trash-o icon-img" title="删除"></a>
								</div>
							</div>
						</td>
					</tr>
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<div class="icon-box-com">
								<div class="icon-box left">
									<a class="fontface3 fa-edit icon-img" title="编辑"></a>
								</div>
								<div class="icon-box left">
									<a class="fontface3 fa-trash-o icon-img" title="删除"></a>
								</div>
							</div>
						</td>
					</tr>
					
				</table>
				
				<br />	
				<br />
				<br />
				<table class="tablelist1">
					<tr>
						<th style="width:20%;">管理员</th>
						<th style="width:20%;">权限组</th>
						<th style="width:20%;">上次登录时间</th>
						<th style="width:20%;">IP</th>
						<th style="width:20%;">操作</th>
						
					</tr>
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<div class="icon-box-com">
								<div class="icon-box left">
									<div class="fontface3 fa-edit icon-img"></div>
									<p class="icon-word">编辑</p>
								</div>
								<div class="icon-box left">
									<div class="fontface3 fa-trash-o icon-img"></div>
									<p class="icon-word">删除</p>
								</div>
							</div>
						</td>
					</tr>
					
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<div class="switch">
	                            <div class="onoffswitch">
	                                <input type="checkbox" checked class="onoffswitch-checkbox" id="example1">
	                                <label class="onoffswitch-label" for="example1">
	                                    <span class="onoffswitch-inner"></span>
	                                    <span class="onoffswitch-switch"></span>
	                                </label>
	                            </div>
	                        </div>
	                       <!-- <div class="td-icon-box"><span class="yes"><i class="fa fa-check-circle"></i>是</span></div>-->
						</td>
					</tr><tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
							<!--<div class="switch">
	                            <div class="onoffswitch">
	                                <input type="checkbox" checked class="onoffswitch-checkbox" id="example1">
	                                <label class="onoffswitch-label" for="example1">
	                                    <span class="onoffswitch-inner"></span>
	                                    <span class="onoffswitch-switch"></span>
	                                </label>
	                            </div>
	                        </div>-->
	                        <div class="td-icon-box"><span class="yes"><i class="fa fa-check-circle"></i>是</span></div>
						</td>
					</tr>
					<tr>
						<td>admin</td>
						<td>商品管理员</td>
						<td>2016-04-08&nbsp;14:34:07</td>
						<td>124.207.8.66</td>
						<td>
	                        <div class="td-icon-box"><span class="no"><i class="fa fa-ban"></i>否</span></div>
						</td>
					</tr>
				</table>
			</div>
		</div>
		
		
		<!--分页开始-->
		<div id="goods_pagination" class="pagination"> 
			<ul>
				<li><span>首页</span></li><li><span>上一页</span></li><li><span class="currentpage">1</span></li>
				<li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=2"><span>2</span></a></li>
				<li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=3"><span>3</span></a></li>
				<li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=4"><span>4</span></a></li>
				<li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=5"><span>5</span></a></li>
				<li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=6"><span>6</span></a></li>
				<li><span>...</span></li><li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=2"><span>下一页</span></a></li>
				<li><a class="demo" href="http://b2b2c.shopnctest.com/tesa/shopnc/modules/mobile/index.php?act=mb_special&amp;op=goods_list&amp;keyword=a&amp;curpage=13"><span>末页</span></a></li>
			</ul> 
		</div>
		<!--分页结束-->
		<button class="alert-btn">弹框按钮</button>
		<!--遮罩层-->
		<div class="cover alert-hide"></div>
		<!--弹框开始-->
		<div class="alertcon radius10 alert-hide">
			<div class="alert-tit boxsizing">
				<h2 class="left">标题标题</h2>
				<button class="closebtn2 right"></button>
			</div>
			<div class="alertcon-box">
				<!--内容-->
				<div class="jurisdiction2">
					<dl class="juris-dl2 boxsizing">
						<dt class="left text-r boxsizing"><span class="redstar">*</span>登录名：</dt>
						<dd class="left text-l">
							<input type="text" class="com-inp1 radius3 boxsizing"/>
							<p class="remind1">这是提示文字</p>
						</dd>
					</dl>
					<dl class="juris-dl2 boxsizing">
						<dt class="left text-r boxsizing"><span class="redstar">*</span>权限组：</dt>
						<dd class="left text-l">
							<select class="com-sele radius3 juris-dl-sele">
								<option>权限一</option>
								<option>权限二</option>
								<option>权限三</option>
								<option>权限四</option>
							</select>
							<p class="remind1">这是提示文字</p>
						</dd>
					</dl>
				</div>
				<div class="btnbox2">
					<a class="btn1 radius3 btn-margin2">取消</a>
					<a class="btn1 radius3 btn-margin2">确定</a>
				</div>
			</div>
			
		</div>
		<!--弹框结束-->
		
		<script type="text/javascript" src="__PUBLIC__/js/jquery.min.js"></script>
		<script type="text/javascript" src="__PUBLIC__/js/common2.js"></script>
		<script type="text/javascript" src="__PUBLIC__/js/alertbox.js"></script>
		<script type="text/javascript" src="__PUBLIC__/js/bootstrap.min.js"></script>
		<script src="__PUBLIC__/js/plugins/switchery/switchery.js"></script>
		












