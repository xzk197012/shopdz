
		<div class="tipsbox">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>操作提示</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.网站全局基本设置，商城及其他模块相关内容在其各容在其各自栏目设置项其各自栏目设置项内进行操作。</li>
				<li>2.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内进行操作。</li>
				<li>3.网站全局基本设置，商城及其他模块相关内容在其各自栏目设置项内在其各自栏目设置项在其各自栏目设置项进行操作。</li>
			</ol>
		</div>
		<div class="iframeCon">
			<div class="white-shadow2">
				<div class="details-box">
					<h1 class="details-tit">确认发货信息及交易详情</h1>
					<div class="order-box boxsizing deliver-top">
						<div class="order-box-Tit boxsizing">
							<p class="left order-tit-p">订单编号<span class="order-tit-span">455644564546</span></p>
							<p class="left order-tit-p">下单时间<span class="order-tit-span">2016-16-07&nbsp;&nbsp;14:05:26</span></p>
							<p class="left order-tit-p">发货时间<span class="order-tit-span">2016-16-07&nbsp;&nbsp;14:05:26</span></p>
							<a href="#" class="getpid">查看物流</a>
						</div>
						<div class="order-box-con">
							<div class="order-box-L boxsizing">
								<div class="order-product-box">
									<dl class="order-product-dl left">
										<dt class="product-dl-dt"><img src="../../static/img/SKU1.jpg" class="product-img1"/></dt>
										<dd class="product-dl-dd boxsizing">
											<div class="order-goods-det shipping-Det">
											几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
											</div>
											<p class="deliver-spec">规格参数</p>
										</dd>
									</dl>
									<div class="product-num right">1件</div>
								</div>
								<div class="order-product-box borderB-none">
									<dl class="order-product-dl left">
										<dt class="product-dl-dt"><img src="../../static/img/SKU1.jpg" class="product-img1"/></dt>
										<dd class="product-dl-dd boxsizing">
											<div class="order-goods-det shipping-Det">
											几个客户的法国海军返回多客户几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方几个客户的法国海军返回多客户的法国海军返回多客户户的法国海军返回多个地方的法国海军返回多客户户的法国海军返回多个地方
											</div>
											<p class="deliver-spec">规格参数</p>
										</dd>
									</dl>
									<div class="product-num right">1件</div>
								</div>
							</div>
							<div class="order-box-R boxsizing">
								<div class="send-details boxsizing">
									<div class="send-details-L left">买家</div>
									<div class="send-details-R left">花花sdkjhk</div>
								</div>
								<div class="send-details boxsizing">
									<div class="send-details-L left">收货人</div>
									<div class="send-details-R left send-person-det boxsizing">
										<p><span class="send-name">邓小姐</span><span class="send-phone">13566894756</span></p>
										<p class="send-address">北京市海淀区上地三街上地三街上地三街上地三街上地三街上地三街金隅嘉华大厦B1107</p>
									</div>
								</div>
								<div class="send-details set-box boxsizing">
									<div class="send-details-L left">运费</div>
									<div class="send-details-R left">
										<p class="left">免运费</p>
										<!--<p class="setDelivery right"><i class="send-car"></i><input type="button" name="" id="" value="设置发货"/></p>-->
										<p class="setDelivery-gray right"><input type="button" name="" id="" value="设置发货"/></p>
									</div>	
								</div>
							</div>
						</div>
					</div>
					<h1 class="details-tit">设置物流信息</h1>
					<div class="jurisdiction boxsizing marginT0">
						<div class="deliver-jusi">
							<dl class="juris-dl boxsizing borderB-none">
								<dt class="left text-r boxsizing">物流方式</dt>
								<dd class="left text-l">
									<div class="button-holder deliver-holder">
										<p class="radiobox deliver-check"><input type="radio" id="radio-1-5" name="radio-1-set" class="regular-radio" checked="checked"/><label for="radio-1-5"></label><span class="radio-word">物流服务</span></p>
										<p class="radiobox deliver-check"><input type="radio" id="radio-1-6" name="radio-1-set" class="regular-radio" /><label for="radio-1-6"></label><span class="radio-word">无需物流</span></p>
									</div>
								</dd>
							</dl>
							<dl class="juris-dl boxsizing borderB-none">
								<dt class="left text-r boxsizing"><span class="redstar">*</span>快递公司</dt>
								<dd class="left text-l">
									<select name="" id="" class="left addFocus-sele">
										<option value="">请选择</option>
										<option value="">操作操作操作</option>
										<option value="">操作操作操作</option>
										<option value="">操作操作操作</option>
										<option value="">操作操作操作</option>
										<option value="">操作操作操作</option>
										<option value="">操作操作操作</option>
										<option value="">操作操作操作</option>
									</select>
								</dd>
							</dl>
							<dl class="juris-dl boxsizing">
								<dt class="left text-r boxsizing"><span class="redstar">*</span>物流单号</dt>
								<dd class="left text-l">
									<input type="text" class="com-inp1 radius3 boxsizing"/>
									<!--<input type="text" class="com-inp1 radius3 boxsizing W140"/>
									<input type="text" class="com-inp1 radius3 boxsizing W160"/>-->
								</dd>
							</dl>
						</div>
						<dl class="juris-dl boxsizing borderB-none deliver-dl-text">
							<dt class="left text-r boxsizing"><span class="redstar">*</span>发货备注</dt>
							<dd class="left text-l">
								<textarea name="" rows="" cols="" class="com-textarea1 radius3 boxsizing"></textarea>
								<p class="remind1">请输入发货备注</p>
							</dd>
						</dl>
						
					</div>
					<div class="btnbox3 boxsizing">
						<input type="button" class="btn1 radius3 btn3-btnmargin left"  value="确认提交">
						<input type="button" class="btn1 radius3 marginT10" value="返回列表">
					</div>
				</div>
			</div>
		</div>

