

<div class="tipsbox">
    <div class="tips boxsizing radius3">
        <div class="tips-titbox">
            <h1 class="tip-tit"><i class="tips-icon-lamp"></i>{$Think.lang.operation_tips}</h1>
            <span class="open-span span-icon"><i class="open-icon"></i></span>
        </div>
    </div>
    <ol class="tips-list" id="tips-list">
        <li>1.平台优惠券添加。</li>
        <li>2.带有红色“<span class="redstar">*</span>”为必填项。</li>
        <li>3.部分字段要求为数字类型，请认真填写。</li>
    </ol>
</div>
<div class="iframeCon">
	<ul class="transverse-nav">
        <li class="activeFour"><a  href="<?php echo U('Coupons/add', array('storeId'=>$ret['store_id'], 'store_name'=>$ret['store_name']));?>"><span>新增优惠券</span></a></li>
    </ul>
    <div class="white-bg text-c">
    	<div class="coupon-con">
            <div class="coupon-left">
                <div class="phoneH"><h2 class="phone-tit">优惠券</h2></div>


                <div class="coupon-box sc-coupon">
                    <div class="coupon-box-det sc-coupon-det">
                        <div class="coupon-box-top">
                            <div class="coupon-top-con">
                                <div class="zoom">
                                    <p class="coupon-subtit left change-title" change-default="">商城优惠券标题</p>
                                    <div class="right">
                                        <p class="coupon-points-none   coupon-share coupon-share1" style="display: block;">免费领取</p>
                                    </div>
                                </div>
                                <div class="zoom couponMoney-box">

                                    <div class="left money" style="display: block;">
                                        <span class="money-unit">¥</span>
                                        <span class="money-num change-price"  change-default="xxx" >xxx</span>
                                    </div>
                                    <div class="left zhe" style="display: none;">
                                        <span class="money-unit">折</span>
                                        <span class="money-num change-price"  change-default="xxx" >xxx</span>
                                    </div>
                                    <div class="right">
                                            <p class="count-limit right">在<span style="color: #f9f900;"></span>可使用</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="coupon-box-bottom">
                            <p class="coupon-bottom-tit">订单满<span class="change-limit coupon-bottom-tit" change-default="xxx">xxx</span>元（含运费）</p>
                            <p class="coupon-remind2">有效期：<span class="change-start coupon-remind2" change-default="20xx-xx-xx">20xx-xx-xx</span>-<span class="change-end coupon-remind2" change-default="20xx-xx-xx">20xx-xx-xx</span></p>
                        </div>
                        <p class="coupon-word"><?php echo $site_name; ?>优惠券</p>
                    </div>
                    <span class="left-circles coupon-circles"></span>
                    <span class="right-circles coupon-circles"></span>
                </div>


            </div>


            <div class="coupon-right">
                 <div class="couponR-con">
                    <div class="coupon-edit-box">
                        <form method="post" class="form-horizontal" name="redpacke_form" id="redpacke_form" action="{:U('Coupons/save')}">
                        <h1 class="soupon-edit-tit">优惠券商家信息</h1>
                        <table class="coupon-table">
                        	<tr>
                        		<td width="100"><span class="redstar">*</span>优惠卷商家</td>
                        		<td>
                        			<input type="hidden" name="store_id" value="{$ret['store_id']}">
                                    <input type="text" class="coupon-inp changenow" localrequired="intval;empty;lt:50" change-key="eachlimit"  name="store_name" value="{$ret['store_name']}" id="rpacket_t_eachlimit"/ disabled="disabled" >
                                    <div class="guanjian">
                                    	
                                    </div>
                                </td>
                        	</tr>
                            <tr>
                                <td width="100"><span class="redstar">*</span>优惠券类型</td>
                                <td>
                                	<select class="coupon-inp changenow leixing" name="coupon_type">
                                		<!-- <option value="0">请选择优惠卷类型</option> -->
                                		<option value="1" selected="selected">满减类型</option>
                                		<option value="2">折扣类型</option>
                                	</select>
                                </td>
                            </tr>
                        </table>
                        <div class="xinxi">
	                        <h1 class="soupon-edit-tit">优惠券基础信息</h1>
	                        <table class="coupon-table">
	                        	<tr>
	                                <td width="100"><span class="redstar">*</span>优惠券名称</td>
	                                <td>
	                                	<input type="text" class="coupon-inp changenow" change-key="title" localrequired="empty;limit:50" name="coupon_name"  value="" id="rpacket_t_title"/>
	                                <span class="tips-tag" title="优惠券名称不能大于50个字符"><i class="tips-icon"></i></span>
	                                <span class="ft"></span>
	                                </td>
	                            </tr>
	                            <tr>
	                                <td><span class="redstar">*</span>发放总量</td>
	                                <td>
	                                	<div class="coupon-full">
	                                    <div class="release-price coupon-table-num left full-num">
	                                        <input type="text" class="price-inp left" localrequired="empty;intval" name="send_num"  value="" id="rpacket_t_total"/>
	                                        <span class="price-unit left">张</span>
	                                    </div>
	                                    <span class="left">可使用</span>
	                                    </div>
	                                </td>
	                            </tr>
	                            <tr class="lijian">
	                                <td><span class="redstar">*</span>面值</td>
	                                <td>
	                                    <div class="release-price coupon-table-num">
	                                        <input type="text" class="price-inp left changenow" change-key="price" localrequired="empty;intval" name="coupon_money"  value="" id="rpacket_t_price"/>
	                                        <span class="price-unit left">元</span>
	                                        <span class="ft">111</span>
	                                    </div>
	                                </td>
	                            </tr>
	                            <tr class="zhekou">
	                                <td><span class="redstar">*</span>折扣</td>
	                                <td>
	                                    <div class="coupon-full">
	                                        <div class="release-price coupon-table-num left full-num">
	                                            <input type="text" class="price-inp left changenow" change-key="price" localrequired="intval;empty;gt:rpacket_t_price" name="discount"  value="" id="rpacket_t_limit"/>
	                                            <span class="price-unit left">折</span>
	                                        </div>
	                                        <span class="left coupon-remind">&nbsp例：8.8</span>
	                                    </div>
	                                </td>
	                            </tr>
	                            <tr>
	                                <td><span class="redstar">*</span>订单金额满</td>
	                                <td>
	                                    <div class="coupon-full">
	                                        <div class="release-price coupon-table-num left full-num">
	                                            <input type="text" class="price-inp left changenow" change-key="limit" localrequired="intval;empty;gt:rpacket_t_price" name="spend_money"  value="" id="rpacket_t_limit"/>
	                                            <span class="price-unit left">元</span>
	                                        </div>
	                                        <span class="left">可使用</span>
	                                        <span class="tips-tag" title="必须大于优惠券面值"><i class="tips-icon"></i></span>
	                                    </div>
	                                </td>
	                            </tr>
	                            
	                        </table>
	                        <h1 class="soupon-edit-tit">基本规则</h1>
	                        <table class="coupon-table">

	                            <tr>
	                                <td><span class="redstar">*</span>生效时间</td>
	                                <td>
	                                    <p class="time-box coupon-time-box"><input type="text" localrequired="empty;time" class="coupon-inp changenow" readonly="" change-key="start" name="valid_start_time"  id="start" ><i class="timeinp-icon"></i></p>
	                                    <span class="tips-tag" title="优惠券启用时间"><i class="tips-icon"></i></span>
	                                </td>
	                            </tr>
	                            <tr>
	                                <td><span class="redstar">*</span>过期时间</td>
	                                <td>
	                                    <p class="time-box coupon-time-box"><input type="text" localrequired="empty;time:start" class="coupon-inp changenow" readonly="" change-key="end" name="valid_end_time"  id="end" ><i class="timeinp-icon"></i></p>
	                                    <span class="tips-tag" title="优惠券过期时间，必须大于启用时间"><i class="tips-icon"></i></span>
	                                </td>
	                            </tr>
	                            <tr class="wxstate">
	                                <td><span class="redstar">*</span>状态</td>
	                                <td>
	                                    <div class="button-holder coupon-holder ">
			                               <p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-7" class="regular-radio" name="status" value="1" checked="checked" ><label for="radio-1-7"></label><span class="radio-word black-font">开放</span></p>

			                                <p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-8" name="status" class="regular-radio" name="rpacket_t_state" value="2"  ><label for="radio-1-8"></label><span class="radio-word black-font">关闭</span></p>
			                            </div>
	                                    <span class="tips-tag" title="启用或关闭优惠卷"><i class="tips-icon top0"></i></span>
	                                </td>
	                            </tr>
	                        </table>
	                        <div class="btn-box-center borderT-none">
					            <input type="hidden" name="submit" value="yes">
					            <button class="btn1 radius3" id="form_submitadd">{$Think.lang.submit_btn}</button>
					            <a class="btn1 radius3 marginL5" href='<?php echo U('/Coupons/lists',array('coupon_type'=>'1')); ?>'>返回列表</a>
					        </div>
				        </div>
                    </form>
                    </div>
                 </div>
                 <s>
                    <i class="bg-jt"></i>
                </s>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
	$("#start").datepicker({
        changeMonth: true,
        changeYear: true,
        showButtonPanel:true,
        dateFormat: 'yy-mm-dd',
        showAnim:"fadeIn",//淡入效果
    });
    $("#end").datepicker({
        changeMonth: true,
        changeYear: true,
        showButtonPanel:true,
        dateFormat: 'yy-mm-dd',
        showAnim:"fadeIn",//淡入效果
    });
	// $('.xinxi').hide();
	var value = $('select[name=coupon_type]').val();
		if(value == 1){
			$('.lijian').show();
			$('.zhekou').hide();
			$('.xinxi').show();
		}
		if(value == 2){
			$('.lijian').hide();
			$('.zhekou').show();
			$('.xinxi').show();
		} 
	$('.leixing').change(function(){
		var value = $(this).val();
		if(value == 1){
			$('.lijian').show();
			$('.zhekou').hide();
			$('.xinxi').show();
		}
		if(value == 2){
			$('.lijian').hide();
			$('.zhekou').show();
			$('.xinxi').show();
		} 
	})

	$(function(){
        store_name = $('input[name=store_name]').val();
        $('.count-limit').find('span').text(store_name);
         type = $('select[name=coupon_type]').val();
    });

    $('select[name=coupon_type]').change(function(){
        type = $(this).val();
        if(type == 2){
            $('.money').css('display','none');
            $('.zhe').css('display','block');
        }else{
            $('.money').css('display','block');
            $('.zhe').css('display','none');
        }
    });

	$('.changenow').bind('keydown keyup change foucs',function(){
        var change_key = $(this).attr('change-key');
        var _change = $(this).val();
        $('.change-'+change_key).each(function(i){
            _this = this;
            if(_change != ''){
                if(change_key == 'points'){
                    if( _change == 0){
                        $(_this).parent().parent().find('.coupon-points-none').show();
                        $(_this).parent().hide();
                    }else{
                        $(_this).parent().parent().find('.coupon-points-none').hide();
                        $(_this).html(_change);
                        $(_this).parent().show();
                    }
                }else{
                    $(_this).html(_change);
                }
            }else{
                $(_this).html($(_this).attr('change-default'));
            }
        });
    });
	
	
</script>