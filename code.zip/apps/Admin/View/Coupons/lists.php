        <div class="tipsbox">
            <div class="tips boxsizing radius3">
                <div class="tips-titbox">
                    <h1 class="tip-tit"><i class="tips-icon-lamp"></i>{$Think.lang.operation_tips}</h1>
                    <span class="open-span span-icon"><i class="open-icon"></i></span>
                </div>
            </div>
            <ol class="tips-list" id="tips-list">
                <li>1.平台优惠券列表。</li>
                <li>2.列表包括所有优惠券模板。</li>
                <li>3.删除、编辑优惠券操作请谨慎进行。</li>
            </ol>
        </div>
<div class="iframeCon">
<div class="iframeMain">
    <ul class="transverse-nav">
        <li class="activeFour"><a href="javascript:;"><span>优惠券</span></a></li>
        <!-- <li><a href="{:U('Admin/Coupon/member_packet')}"><span>用户优惠券</span></a></li> -->
        <li><a href="{:U('Store/browse')}"><span>添加优惠卷</span></a></li>
    </ul>
    <div class="white-bg">
        <div class="table-titbox">
        <div class="option">
            <h1 class="table-tit left boxsizing"><a href="<?php echo U('/Coupons/lists',array('coupon_type'=>'1')); ?>" <?php if($type == '2'){echo "style='color:#ADADAD'";} ?>>满减类优惠卷</a></h1>
            <h1 class="table-tit left boxsizing"><a href="<?php echo U('/Coupons/lists',array('coupon_type'=>'2')); ?>" <?php if($type == '1'){echo "style='color:#ADADAD'";} ?>>折扣类优惠卷</a></h1>
            <ul class="operation-list left">
                <li class="add-li" onclick="location.href='{:U('Store/browse')}'"><a href="javascript:;"><span><i href="#" class="operation-icon add-icon"></i></span></a></li>
                <li class="refresh-li" onclick="location.reload();"><a href="javascript:;"><span><i href="#" class="operation-icon refresh-icon"></i></span></a></li>
            </ul>
        </div>
            
            <form  method="post" class="form-horizontal" name="Search_form" action="{:U('coupons/lists',array('coupon_type'=>$type))}" >
                <div class="search-box1 right">
                    <div class="search-boxcon boxsizing radius3 left">
                       优惠卷名：<input type="text" name="coupon_name" value="{$sousuo['coupon_name']}" class="search-inp-con boxsizing" placeholder="优惠卷名"  />
                        商家名：<input type="text" name="store_name" value="{$sousuo['store_name']}" class="search-inp-con boxsizing"   placeholder="商家名" />
                    </div>
                    <input type="submit"  value="搜索" class="search-btn right radius3"/>
                </div>
            </form>
            
        </div>
        <?php if($type == '1'){?>
        <div class="comtable-box boxsizing">
            <table class="com-table">
                <thead>
                    <tr>
                        <th width="260">操作</th>
                        <th width="220">优惠券名称</th>
                        <th  width="220">所属商家</th>
                        <!-- <th width="80">兑换积分</th>` -->
                        <th width="80">面额</th>
                        <th width="80">消费金额</th>
                        <th width="150">使用有效期</th>
                        <th width="120">卡券类型</th>
                        <th width="120">状态</th>
                        <th width="80">未领数量</th>
                        <th width="80">已领数量</th>
                        <!-- <th></th> -->
                    </tr>
                </thead>
                <tbody>
                 <tbody>
                    <?php if(empty($coupons) || $coupons['count'] == 1){  ?>
                        <tr class="tr-minH">
                            <td colspan="8">暂无数据！</td>
                            <td></td>
                        </tr>
                    <?php }else{ ?>
                        <?php foreach($coupons  as $v){ ?>
                        <tr>
                            <td>
                                <div class="table-iconbox">
                                    <div class="edit-iconbox left edit-sele marginR10">
                                        <a class="edit-word table-icon-a" href="javascript:void(0);" onclick="del({$v['coupon_id']})"><i class="table-com-icon table-dele-icon"></i><span class="gap">删除</span></a>
                                    </div>
                                    <div class="edit-iconbox left edit-sele marginR10">
                                        <a class="edit-word table-icon-a" href="<?php echo  U("Coupons/edit",array('coupon_id'=>$v['coupon_id'],'submit'=>'yes')); ?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">编辑</span></a>
                                    </div>
                                </div>
                            </td>
                            <td ><?php echo $v['coupon_name']?></td>
                            <td ><?php echo $v['store_name']?></td>
                            <td ><?php echo $v['coupon_money']?></td>
                            <td ><?php echo $v['spend_money']?></td>
                            <td ><?php echo $v['valid_end_time']?></td>
                            <td >
                            <?php
                             if($v['coupon_type'] == 1){echo '满减';}else if($v['coupon_type'] == 2){ echo '折扣';}
                             ?>
                             </td>
                            <td >
                                <?php
                                    if($v['status'] == 1){echo '开放';}else if($v['status'] == 2){echo '关闭';}
                                ?>
                            </td>
                            <td><?php echo $v['send_num']?></td>
                            <td><?php echo $v['receive_num']?></td>
                        </tr>
                        <?php } ?>
                    <?php } ?>
                </tbody>
                </tbody>
            </table>
        </div>
        <?php }else if($type == '2'){ ?>
            <div class="comtable-box boxsizing">
            <table class="com-table">
                <thead>
                    <tr>
                        <th width="260">操作</th>
                        <th width="220">优惠券名称</th>
                        <th  width="220">所属商家</th>
                        <!-- <th width="80">兑换积分</th>` -->
                        <th width="80">折扣</th>
                        <th width="80">消费金额</th>
                        <th width="150">使用有效期</th>
                        <th width="120">卡券类型</th>
                        <th width="120">状态</th>
                        <th width="80">未领数量</th>
                        <th width="80">已领数量</th>
                        <!-- <th></th> -->
                    </tr>
                </thead>
                <tbody>
                 <tbody>
                    <?php if(empty($coupons) || $coupons['count'] == 1){  ?>
                        <tr class="tr-minH">
                            <td colspan="8">暂无数据！</td>
                            <td></td>
                        </tr>
                    <?php }else{ ?>
                        <?php foreach($coupons  as $v){ ?>
                        <tr>
                            <td>
                                <div class="table-iconbox">
                                    <div class="edit-iconbox left edit-sele marginR10">
                                        <a class="edit-word table-icon-a" href="javascript:void(0);" onclick="del({$v['coupon_id']})"><i class="table-com-icon table-dele-icon"></i><span class="gap">删除</span></a>
                                    </div>
                                    <div class="edit-iconbox left edit-sele marginR10">
                                        <a class="edit-word table-icon-a" href="<?php echo  U("Coupons/edit",array('coupon_id'=>$v['coupon_id'],'submit'=>'yes')); ?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">编辑</span></a>
                                    </div>
                                </div>
                            </td>
                            <td ><?php echo $v['coupon_name']?></td>
                            <td ><?php echo $v['store_name']?></td>
                            <td ><?php echo $v['discount']?></td>
                            <td ><?php echo $v['spend_money']?></td>
                            <td ><?php echo $v['valid_end_time'];?></td>
                            <td >
                            <?php
                             if($v['coupon_type'] == 1){echo '满减';}else if($v['coupon_type'] == 2){ echo '折扣';} 

                             ?>
                             </td>
                            <td >
                                <?php
                                    if($v['status'] == 1){echo '开放';}else if($v['status'] == 2){echo '关闭';}
                                ?>
                            </td>
                            <td><?php echo $v['send_num']?></td>
                            <td><?php echo $v['receive_num']?></td>
                        </tr>
                        <?php } ?>
                    <?php } ?>
                </tbody>
                </tbody>
            </table>
        </div>
        <?php }?>    
        {$page}
    </div>
</div>
</div>

<script type="text/javascript">
    $(function(){
        //添加会员提示
        $('.add-li').mousemove(function(){
            e=arguments.callee.caller.arguments[0] || window.event; 
            remindNeed($('.add-li'),e,'添加优惠券');
        })
        $('.add-li').mouseout(function(){
            $('.tip-remind').remove();
        });
        $('.refresh-li').mousemove(function(){
            e=arguments.callee.caller.arguments[0] || window.event; 
            remindNeed($('.add-li'),e,'刷新');
        })
        $('.refresh-li').mouseout(function(){
            $('.tip-remind').remove();
        });
        $('.export-li').mousemove(function(){
            e=arguments.callee.caller.arguments[0] || window.event; 
            remindNeed($('.add-li'),e,'导出');
        })
        $('.export-li').mouseout(function(){
            $('.tip-remind').remove();
        });
    })
    function del(id) {
        // console.log(id);
        showConfirm("用户已领优惠卷也会失效，确认删除？",function(){
            $.get('<?php echo U('Coupons/delete')?>',{submit:'yes',coupon_id:id},function(data){
                if(data.status == '1'){
                   showSuccess(data.info,function(){
                        window.location.reload();
                  });
                }else{
                    showError(data.info);
                }
            },'json')
        });
    }  
</script>