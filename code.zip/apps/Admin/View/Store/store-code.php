<!--内容开始-->
   		<div class="tipsbox radius3">
			<div class="tips boxsizing radius3">
				<div class="tips-titbox">
					<h1 class="tip-tit"><i class="tips-icon-lamp"></i>{$Think.lang.operation_tips}</h1>
					<span class="open-span span-icon"><i class="open-icon"></i></span>
				</div>
			</div>
			<ol class="tips-list" id="tips-list">
				<li>1.每家商户生成的二维码都独一无二的。</li>
			</ol>
		</div>
		<div class="iframeCon">
		<div class="iframeMain">
			<ul class="transverse-nav">
				<li <if condition="$status eq ''">class="activeFour"</if>><a href="<?= U('Store/code',array('store_id'=>$store_id));?>"><span>二维码</span></a></li>
			</ul>
			<if condition="$status eq ''">
			<div class="white-bg ">
				<div  style="margin:20px;">
					<div id="qrcodeCanvas"></div>
					<!-- <img src="__PUBLIC__/admin/images/otherpay.png" alt="" title="扫码支付二维码" > -->
					<h1 class="table-tit boxsizing down left" >右键另存为，下载二维码</h1>
				</div>
			</div>
			</if>
		</div>	
	</div>
		<!--内容结束-->
	<script type="text/javascript" src="__PUBLIC__/admin/js/qrcode/utf.js"></script>
	<script type="text/javascript" src="__PUBLIC__/admin/js/qrcode/jquery.qrcode.js"></script>
	<script>
		$(document).ready(function() {
	        $("#qrcodeCanvas").qrcode({
	            render : "canvas",    //设置渲染方式，有table和canvas，使用canvas方式渲染性能相对来说比较好
	            text : "{$qrcode_url}",    //扫描二维码后显示的内容,可以直接填一个网址，扫描二维码后自动跳向该链接
	            width : "200",               //二维码的宽度
	            height : "200",              //二维码的高度
	            background : "#ffffff",       //二维码的后景色
	            foreground : "#000000",        //二维码的前景色
	            src: "{$logo_url}"             //二维码中间的图片
	        });
	        
	    });

	</script>
	