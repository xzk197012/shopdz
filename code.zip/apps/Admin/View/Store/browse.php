        <div class="tipsbox">
            <div class="tips boxsizing radius3">
                <div class="tips-titbox">
                    <h1 class="tip-tit"><i class="tips-icon-lamp"></i>{$Think.lang.operation_tips}</h1>
                    <span class="open-span span-icon"><i class="open-icon"></i></span>
                </div>
            </div>
            <ol class="tips-list" id="tips-list">
                <li>1.平台商家列表。</li>
                <li>2.删除、编辑商家操作请谨慎进行。</li>
            </ol>
        </div>
<div class="iframeCon">
<div class="iframeMain">
    <ul class="transverse-nav">
        <li class="activeFour"><a href="<?php U('Store/index')?>"><span>商家</span></a></li>
        <!-- <li><a href="{:U('Admin/Coupon/member_packet')}"><span>用户优惠券</span></a></li> -->
        <li><a href="{:U('Store/add')}"><span>新增商家</span></a></li>
    </ul>
    <div class="white-bg">
        <div class="table-titbox">
        <div class="option">
            <h1 class="table-tit left boxsizing">商家列表</h1>
            <ul class="operation-list left">
                <li class="add-li" onclick="location.href='{:U('Store/add')}'"><a href="javascript:;"><span><i href="#" class="operation-icon add-icon"></i></span></a></li>
                <li class="refresh-li" onclick="location.reload();"><a href="javascript:;"><span><i href="#" class="operation-icon refresh-icon"></i></span></a></li>
                <!-- <li class="export-li"><a href="javascript:;"><span><i href="#" class="operation-icon export-icon"></i></span></a></li> -->
            </ul>
        </div>
            
            <form  method="post" class="form-horizontal" name="Search_form" action='{:U("Store/browse")}' >
                <div class="search-box1 right">
                    <div class="search-boxcon boxsizing radius3 left">
                        <select class="sele-com1 search-sele boxsizing" id="rpacket_select" name="status">
                            <option value="0">商家状态</option>
                            <option value="1">开放</option>
                            <option value="2">关闭</option>
                        </select>
                        <input type="text" name="store_name" class="search-inp-con boxsizing" placeholder="商家名称" />
                    </div>
                    <input type="submit"  value="搜索" class="search-btn right radius3"/>
                </div>
            </form>
            
        </div>
        
        <div class="comtable-box boxsizing">
            <table class="com-table">
                <thead>
                    <tr>
                        <th width="280">操作</th>
                        <th width="160">商家名称</th>
                        <th width="220">商家地址</th>
                        <th width="80">商家电话</th>
                        <th width="200">商家简介</th>
                        <!-- <th width="150">商家状态</th> -->
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                    <empty name="list">
                    <?php if($count != 0){?>
                    <?php foreach($ret as $k=>$v){?>
                        <tr class="" style="height: 50px;">
                            <td>
                                <div class="table-iconbox">
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="<?php echo U('Store/edit', array('store_id'=>$v['id']));?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">编辑</span></a>
                                </div>
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="javascript:void(0);" onclick="del(<?php echo $v['id']; ?>)"><i class="table-com-icon table-dele-icon"></i><span class="gap">删除</span></a>
                                </div>
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="<?php echo U('Coupons/add', array('store_id'=>$v['id'], 'store_name'=>$v['store_name']));?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">优惠卷</span></a>
                                </div>
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="<?php echo U('Store/code', array('store_id'=>$v['id'], 'store_name'=>$v['store_name']));?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">二维码</span></a>
                                </div>
                            </div>
                            </td>
                            <td><?=$v['store_name'];?></td>
                            <td><?=$v['address'];?></td>
                            <td><?=$v['store_tel'];?></td>
                            <td><?=$v['details'];?></td>
                            <!-- <td>
                                <?php
                                 if ($v['status'] == '1'){echo "开放";}
                                 if ($v['status'] == '2'){echo "关闭";}
                                ?>
                            </td> -->
                        </tr>
                    <?php }; ?>
                    <?php } else {?>
                        <tr class="tr-minH">
                            <td colspan="8">暂无数据！</td>
                            <td></td>
                        </tr>
                    <?php } ?>    
                    </empty>
                </tbody>
            </table>
        </div>
        <div>{$page}</div>
    </div>
</div>
</div>

<script type="text/javascript">
     function del(id){
        // console.log(id);
        showConfirm('你确定删除此商家吗?', function(){
            $.get('<?php echo U('Store/del')?>',{submit:'yes',store_id:id},function(data){
                if(data.status == '1'){
                   showSuccess(data.info,function(){
                        window.location.reload();
                  });
                }else{
                    showError(data.info);
                }
            },'json')
        });
     }
</script>