
<div class="tipsbox radius3">
    <div class="tips boxsizing radius3">
        <div class="tips-titbox">
            <h1 class="tip-tit"><i class="tips-icon-lamp"></i>{$Think.lang.operation_tips}</h1>
            <span class="open-span span-icon"><i class="open-icon"></i></span>
        </div>
    </div>
    <ol class="tips-list" id="tips-list">
        <li>1.商家信息修改，请谨慎操作。</li>
    </ol>
</div>

<!--内容开始-->
<div class="iframeCon">
<div class="iframeMain">
    <ul class="transverse-nav">
        <li class="activeFour"><a href="<?php echo U('Store/edit', array('store_id'=>$data[0]['id']));?>"><span>商家信息修改</span></a></li>
    </ul>
    <div class="white-bg">
        <form  method="post"  autocomplte="off"  action="{:U('Store/save')}"   method="post"  id="main_form"  >  
            <div class="tab-conbox">
                <div class="jurisdiction boxsizing">
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家名称：</dt>
                        <dd class="left text-l">
                            <input type="text" name="store_name" localrequired="localrequired"  class="com-inp1 radius3 boxsizing"  value="<?php echo $data[0]['store_name']; ?>" readonly="readonly">
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家地址：</dt>
                        <dd class="left text-l">
                            <input type="text" name="address"   localrequired="localrequired"  class="com-inp1 radius3 boxsizing"  value="<?php echo $data[0]['address']; ?>" />
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家电话：</dt>
                        <dd class="left text-l">
                            <input type="text" name="store_tel"   localrequired="localrequired"  class="com-inp1 radius3 boxsizing"  value="<?php echo $data[0]['store_tel']; ?>"/>
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing">商家简介：</dt>
                        <dd class="left text-l">
                            <textarea name ='details' type="text" class="com-textarea1 radius3 boxsizing" placeholder="请填写商家简介" >{$data[0]['details']}</textarea>
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家状态：</dt>
                        <dd class="left text-l">
                            <div class="button-holder coupon-holder ">
                               <p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-7" class="regular-radio" name="status" value="1" <?php if($data[0]['status'] == 1) echo "checked='checked'";?> ><label for="radio-1-7"></label><span class="radio-word black-font">开放</span></p>

                                <p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-8" name="status" class="regular-radio" name="rpacket_t_state" value="2" <?php if($data[0]['status'] == 2) echo "checked='checked'";?> ><label for="radio-1-8"></label><span class="radio-word black-font">关闭</span></p>
                            </div>
                        </dd>
                    </dl>
                </div>
                <div class="btnbox3  submit_div  boxsizing ">
                    <input type="hidden" name="submit" value="yes" >
                    <input type="hidden" name="storeId" id="icon_url" value="{$data[0]['id']}" />
                    <button id="submit_button" class="btn1 radius3 marginT10  btn3-btnmargin">{$Think.lang.submit_btn}</button>
                    <a class="btn1 radius3 marginT10 " href="{:U('Store/browse')}">返回列表</a>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<div class="icon-cover none"></div>
<script>
    
</script>
