<div class="tipsbox radius3">
    <div class="tips boxsizing radius3">
        <div class="tips-titbox">
            <h1 class="tip-tit"><i class="tips-icon-lamp"></i>{$Think.lang.operation_tips}</h1>
            <span class="open-span span-icon"><i class="open-icon"></i></span>
        </div>
    </div>
    <ol class="tips-list" id="tips-list">
        <li>1.商品分类将会对应到前台的商品分类列表里，添加新商品时可选择添加到某分类下。</li>
        <li>2.上级分类默认为顶级分类（一级分类），上级分类选择一级类分类则新建的分类为二级分类。</li>
        <li>3.分类描述会显示在商城分类列表的顶部。</li>
        <li>4.可对分类设置开启或关闭显示。</li>
        <li>5.可填写分类的排序值来调节分类的显示顺序，分类值越大显示的优先级越高。</li>
    </ol>
</div>

<!--内容开始-->
<div class="iframeCon">
<div class="iframeMain">
    <ul class="transverse-nav">
        <li class="activeFour"><a href="<?php echo U('Store/add');?>"><span>添加商家</span></a></li>
    </ul>
    <div class="white-bg">
        <form  method="post"  autocomplte="off"  action="{:U('Admin/Store/save')}"   method="post"  id="main_form"  >  
            <div class="tab-conbox">
                <div class="jurisdiction boxsizing">
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家名称：</dt>
                        <dd class="left text-l">
                            <input type="text" name="store_name"   localrequired="localrequired"  class="com-inp1 radius3 boxsizing"  placeholder="请填写商家名称"/>
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家地址：</dt>
                        <dd class="left text-l">
                            <input type="text" name="address"   localrequired="localrequired"  class="com-inp1 radius3 boxsizing"  placeholder="请填写商家地址"/>
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家电话：</dt>
                        <dd class="left text-l">
                            <input type="text" name="store_tel"   localrequired="localrequired"  class="com-inp1 radius3 boxsizing"  placeholder="请填写商家电话"/>
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing">商家简介：</dt>
                        <dd class="left text-l">
                            <textarea name ='details' type="text" class="com-textarea1 radius3 boxsizing" placeholder="请填写商家简介" ></textarea>
                            <span></span>
                        </dd>
                    </dl>
                    <dl class="juris-dl boxsizing">
                        <dt class="left text-r boxsizing"><span class="redstar">*</span>商家状态：</dt>
                        <dd class="left text-l">
                            <div class="button-holder coupon-holder ">
                               <p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-7" class="regular-radio" name="status" value="1" checked="checked"><label for="radio-1-7"></label><span class="radio-word black-font">开放</span></p>

                                <p class="radiobox coupon-radiobox"><input type="radio" id="radio-1-8" name="status" class="regular-radio" name="rpacket_t_state" value="2"  ><label for="radio-1-8"></label><span class="radio-word black-font">关闭</span></p>
                            </div>
                        </dd>
                    </dl>                
                </div>

                <div class="btnbox3  submit_div  boxsizing ">
                    <input type="hidden" name="submit" value="yes" />
                    <button id="submit_button" class="btn1 radius3 marginT10  btn3-btnmargin">{$Think.lang.submit_btn}</button>
                    <a class="btn1 radius3 marginT10 " href="{:U('Store/browse')}">返回列表</a>
                </div>
            </div>
        </form>
    </div>
</div>
</div>
<div class="icon-cover none"></div>
<script>
    
</script>
