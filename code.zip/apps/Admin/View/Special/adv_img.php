<div class="topic-list">
    			<!--<p class="topic-tit">专题</p>-->
    			<div class="list-con">
    				<foreach name="vo.item_data" item="vo1" key="k">
    				<div class="list-img"><a href=""><img src="__ATTACH_HOST__{$vo1.img}"/></a></div>
    				</foreach>
    			</div>
    			<!--<div class="more-box1"><a href="#" class="morebtn1">查看更多</a></div>-->
    		</div>