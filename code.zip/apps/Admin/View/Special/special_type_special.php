<if condition="!$edit">
    <div class="topic-list">
        <p class="topic-tit">专题</p>
        <div class="list-con">
            <div class="list-img"><a href="list.html"><img src="img/img1.jpg"/></a></div>
            <div class="list-img"><a href="list.html"><img src="img/img2.jpg"/></a></div>
            <div class="list-img"><a href="list.html"><img src="img/img3.jpg"/></a></div>
        </div>
        <div class="more-box1"><a href="#" class="morebtn1">查看更多</a></div>
    </div>
<else />

</if>