<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>


<!-- Mirrored from www.zi-han.net/theme/hplus/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Jan 2016 14:16:41 GMT -->
<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="renderer" content="webkit">
    <meta http-equiv="Cache-Control" content="no-siteapp" />
    <!--[if lt IE 9]>
    <meta http-equiv="refresh" content="0;ie.html" />
    <![endif]-->
    <link rel="shortcut icon" href="/static/favicon.ico">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/scrollbar.css" />
    <link rel="stylesheet" type="text/css" href="/static/admin/css/style.min862f.css?v=4.1.0">
    <link rel="stylesheet" type="text/css" href="/static/admin/css/reset.css"/>
    <link rel="stylesheet" type="text/css" href="/static/admin/css/index.css"/>
    <link rel="stylesheet" href="/static/admin/css/jquery-ui.css">
    <link href="/static/admin/css/jquery-ui-timepicker-addon.css" type="text/css" />
    <script type="text/javascript" src="/static/admin/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="/static/admin/js/select.js"></script>
    <script type="text/javascript" src="/static/js/jquery.md5.js"></script>
    <script type="text/javascript" src="/static/admin/js/plupload-2.0.0/plupload.full.min.js"></script>
    <script src="/static/admin/js/jquery-ui.js"></script>
    <script src="/static/admin/js/jquery-ui-timepicker-addon.js" type="text/javascript"></script>
    <script src="/static/admin/js/jquery.ui.datepicker-zh-CN.js.js" type="text/javascript" charset="gb2312"></script>
    <script src="/static/admin/js/jquery-ui-timepicker-zh-CN.js" type="text/javascript"></script>
    <script type="text/javascript" src="/static/admin/js/posi-img.js"></script>
    <script type="text/javascript">
		var  __BASE__= '<?=$baseUrl?>';
    </script>
</head>
<body class="gray-bg">
    <div class="scrollbox" style="overflow-y: scroll; overflow-x: hidden;">
        <div id='append_parent'></div>
    	        <div class="tipsbox">
            <div class="tips boxsizing radius3">
                <div class="tips-titbox">
                    <h1 class="tip-tit"><i class="tips-icon-lamp"></i><?php echo (L("operation_tips")); ?></h1>
                    <span class="open-span span-icon"><i class="open-icon"></i></span>
                </div>
            </div>
            <ol class="tips-list" id="tips-list">
                <li>1.平台商家列表。</li>
                <li>2.删除、编辑商家操作请谨慎进行。</li>
            </ol>
        </div>
<div class="iframeCon">
<div class="iframeMain">
    <ul class="transverse-nav">
        <li class="activeFour"><a href="<?php U('Store/index')?>"><span>商家</span></a></li>
        <!-- <li><a href="<?php echo U('Admin/Coupon/member_packet');?>"><span>用户优惠券</span></a></li> -->
        <li><a href="<?php echo U('Store/add');?>"><span>新增商家</span></a></li>
    </ul>
    <div class="white-bg">
        <div class="table-titbox">
        <div class="option">
            <h1 class="table-tit left boxsizing">商家列表</h1>
            <ul class="operation-list left">
                <li class="add-li" onclick="location.href='<?php echo U('Store/add');?>'"><a href="javascript:;"><span><i href="#" class="operation-icon add-icon"></i></span></a></li>
                <li class="refresh-li" onclick="location.reload();"><a href="javascript:;"><span><i href="#" class="operation-icon refresh-icon"></i></span></a></li>
                <!-- <li class="export-li"><a href="javascript:;"><span><i href="#" class="operation-icon export-icon"></i></span></a></li> -->
            </ul>
        </div>
            
            <form  method="post" class="form-horizontal" name="Search_form" action='<?php echo U("Store/browse");?>' >
                <div class="search-box1 right">
                    <div class="search-boxcon boxsizing radius3 left">
                        <select class="sele-com1 search-sele boxsizing" id="rpacket_select" name="status">
                            <option value="0">商家状态</option>
                            <option value="1">开放</option>
                            <option value="2">关闭</option>
                        </select>
                        <input type="text" name="store_name" class="search-inp-con boxsizing" placeholder="商家名称" />
                    </div>
                    <input type="submit"  value="搜索" class="search-btn right radius3"/>
                </div>
            </form>
            
        </div>
        
        <div class="comtable-box boxsizing">
            <table class="com-table">
                <thead>
                    <tr>
                        <th width="280">操作</th>
                        <th width="160">商家名称</th>
                        <th width="220">商家地址</th>
                        <th width="80">商家电话</th>
                        <th width="200">商家简介</th>
                        <!-- <th width="150">商家状态</th> -->
                        <th></th>
                    </tr>
                </thead>
                <tbody>

                    <?php if(empty($list)): if($count != 0){?>
                    <?php foreach($ret as $k=>$v){?>
                        <tr class="" style="height: 50px;">
                            <td>
                                <div class="table-iconbox">
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="<?php echo U('Store/edit', array('store_id'=>$v['id']));?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">编辑</span></a>
                                </div>
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="javascript:void(0);" onclick="del(<?php echo $v['id']; ?>)"><i class="table-com-icon table-dele-icon"></i><span class="gap">删除</span></a>
                                </div>
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="<?php echo U('Coupons/add', array('store_id'=>$v['id'], 'store_name'=>$v['store_name']));?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">优惠卷</span></a>
                                </div>
                                <div class="edit-iconbox left edit-sele marginR10">
                                    <a class="edit-word table-icon-a" href="<?php echo U('Store/code', array('store_id'=>$v['id'], 'store_name'=>$v['store_name']));?>"><i class="table-com-icon table-edit-icon"></i><span class="gap">二维码</span></a>
                                </div>
                            </div>
                            </td>
                            <td><?=$v['store_name'];?></td>
                            <td><?=$v['address'];?></td>
                            <td><?=$v['store_tel'];?></td>
                            <td><?=$v['details'];?></td>
                            <!-- <td>
                                <?php
 if ($v['status'] == '1'){echo "开放";} if ($v['status'] == '2'){echo "关闭";} ?>
                            </td> -->
                        </tr>
                    <?php }; ?>
                    <?php } else {?>
                        <tr class="tr-minH">
                            <td colspan="8">暂无数据！</td>
                            <td></td>
                        </tr>
                    <?php } endif; ?>
                </tbody>
            </table>
        </div>
        <div><?php echo ($page); ?></div>
    </div>
</div>
</div>

<script type="text/javascript">
     function del(id){
        // console.log(id);
        showConfirm('你确定删除此商家吗?', function(){
            $.get('<?php echo U('Store/del')?>',{submit:'yes',store_id:id},function(data){
                if(data.status == '1'){
                   showSuccess(data.info,function(){
                        window.location.reload();
                  });
                }else{
                    showError(data.info);
                }
            },'json')
        });
     }
</script>
    </div>
		<script type="text/javascript" src="/static/admin/js/iscroll.js"></script>
        <script type="text/javascript" src="/static/admin/js/common.js"></script>
        <script type="text/javascript" src="/static/admin/js/common_branch.js"></script>
        <script type="text/javascript" src="/static/admin/js/remindMove.js"></script>
        <script type="text/javascript" src="/static/admin/js/getdata.js"></script>
        <script type="text/javascript" src="/static/admin/js/iframe.js"></script>
        <script type="text/javascript" src="/static/admin/js/jquery.mousewheel.min.js"></script>
        <script type="text/javascript" src="/static/admin/js/scrollbar.min.js"></script>
        <script type="text/javascript" src="/static/admin/js/buttons.js"></script>
		<script type="text/javascript">
				var settting = <?= $setting?>;
				//显示左侧标签
				var main_li="<?php echo (CONTROLLER_NAME); ?>";
				var second_li="<?php echo (ACTION_NAME); ?>";
				$('.main_'+main_li, window.parent.document).siblings().removeClass('activeOne');
				$('.main_'+main_li, window.parent.document).addClass('activeOne');
				$('.main_'+main_li, window.parent.document).find("ul").show().parents('li').siblings().find("ul").hide();
				$('.secondary_'+second_li, window.parent.document).siblings().removeClass('activeThree');
				$('.secondary_'+second_li, window.parent.document).addClass('activeThree');
				module = $('.activeOne',window.parent.document).find('a:eq(0)').text();
				action = $('.activeOne',window.parent.document).find('ul').find('.activeThree').text();
				$('title',window.parent.document).html(settting.shop_name +'-'+module+'-'+action);
		</script>
</body>

</html>