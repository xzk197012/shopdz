<?php
return array(
    'app_begin' => array('Behavior\CheckLangBehavior'),
    'PayAfter' => array('App\Behaviors\PayAfterBehavior'),
);